---
name: vulcan-technical-analysis
description: use this for Phoenix technical indicators and trigger evaluation
---
Read-only TA: `vulcan ta compute`, `vulcan ta signal`, `vulcan ta report`. RSI, MACD, BBands, ATR, ADX, VWAP, Stoch, SMA, EMA. Signals are not orders.
