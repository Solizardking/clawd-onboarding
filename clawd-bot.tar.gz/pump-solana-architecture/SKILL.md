---
name: pump-solana-architecture
description: >-
  use this when designing Pump.fun Solana PDAs, account layouts, global
  singletons, or cross-program coordination across Pump, PumpAMM, PumpFees, and
  Mayhem
---
# Pump.fun Solana program architecture

Design PDAs, account layouts, and cross-program flow across Pump, PumpAMM, PumpFees, and Mayhem. Canonical IDs and seeds: https://github.com/pump-fun/pump-public-docs. Prefer [pump-program-ids](sand-workflow:pump-program-ids) when you only need addresses.

| Program | ID | Role |
|---------|-----|------|
| Pump | `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P` | Bonding curve |
| PumpAMM | `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA` | Graduated AMM |
| PumpFees | `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ` | Fee sharing + fee_config |
| Mayhem | `MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e` | Mayhem-mode tokens |

## Seeds (get these right)

Global (Pump): `["global"]` → `4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf`. Volume: `["global_volume_accumulator"]`.

Fee config lives on **PumpFees**, not Pump: `["fee_config", pump_program_id]`. AMM GlobalConfig: `["global_config"]` → `ADyA8hdefvWN2dbGGWFotbzWxrAvLW83WG6QCVXvJKqw`.

Per-token: `["bonding-curve", mint]`, sharing `["sharing-config", mint]` on PumpFees, canonical pool via pump-swap-sdk (`canonicalPumpPoolPda`, index 0).

Per-user / creator: Pump vault hyphen `["creator-vault", creator]`; AMM vault underscore `["creator_vault", coin_creator]`. UVA `["user_volume_accumulator", user]` exists **twice** (Pump and PumpAMM, same seeds, different program).

Mayhem accounts on create_v2 are always present even if mayhem is false (mayhem program, global-params, sol-vault, mayhem-state, mayhem-token-vault).

## Flow

create / buy / sell on Pump → permissionless `migrate` / `migrate_v2` → PumpAMM. Fees program sits beside both. SDK BothPrograms helpers: `getCreatorVaultBalanceBothPrograms`, `collectCoinCreatorFeeInstructions`, volume/incentive totals across programs.

Use `findProgramAddressSync`. Batch with `getMultipleAccountsInfo`. Nullable decoders. If bonding-curve data is short, prepend `extendAccount` (v2 trades top-up toward 115 bytes; older creator-fee docs used 150/151). Decode BondingCurve/Pool/Global/FeeConfig via pump-rust-client `AccountWrapper` (zero-pads short accounts); raw IDL types fail on legacy accounts.

Common fails: hyphen vs underscore vault seeds; treating fee_config as a Pump PDA; deriving canonical pool on the Pump program; ignoring the second UVA.
