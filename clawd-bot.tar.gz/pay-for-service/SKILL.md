---
name: pay-for-service
description: >-
  use this to pay an x402 or MPP 402-gated API from awal (Base) or Solana
  pay-kit
---
# Pay for an x402 service

Pay a 402-gated API. Confirm price from `x402 details` first.

Base/awal: follow awal pay-for-service after auth.

Solana: `@solana/pay-kit/client` `createPayKitClient({ signer, rpcUrl })` then `client.fetch(url)`. On 402 it pays and retries. Prefer OWS as signer — never load a raw `SECRET` / `BS58_PRIVATE_KEY`. Optional third arg `'x402'` to pin the rail vs MPP. Sessions: `createSessionFetch` with payment-channel opener. Operator confirms the spend.
