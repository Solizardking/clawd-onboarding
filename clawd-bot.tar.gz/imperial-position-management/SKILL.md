---
name: imperial-position-management
description: >-
  use this to inspect, reduce, or close Imperial-routed positions across
  Phoenix, Flash, Jupiter, GMTrade
---
List/reduce/close Imperial-routed positions (Phoenix default; Flash, Jupiter, GMTrade if asked). Close-side `action=1` market. Match `profileIndex`. After non-USDC venues consider `/passthrough/users/{wallet}/profiles/{index}/sync`.
