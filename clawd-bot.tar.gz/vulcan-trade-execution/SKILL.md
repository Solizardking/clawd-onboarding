---
name: vulcan-trade-execution
description: >-
  use this for safe Phoenix order execution via Vulcan: pre-trade checks,
  market/limit, paper/live gates
---
Safe Phoenix orders via Vulcan. Live needs market info, margin, positions, explicit yes, `--yes`, event reporting, post-trade verify. Prefer `--tokens` or `--notional-usdc`. Paper first. Report signatures.
