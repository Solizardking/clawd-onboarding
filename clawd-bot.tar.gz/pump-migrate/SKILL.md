---
name: pump-migrate
description: >-
  use this when migrating a completed pump.fun curve to PumpSwap or
  adding/removing AMM LP
---
# Pump.fun migrate and AMM LP

Completed curve = `complete == true` AND `real_token_reserves == 0`. `migrate` / `migrate_v2` are permissionless and idempotent. Docs: https://github.com/pump-fun/pump-public-docs (`docs/PUMP_SWAP_README.md`)

- `migrate`: legacy SOL + SPL Token only (wSOL hardcoded).
- `migrate_v2`: Token-2022 base and/or non-SOL quote. Pass both `base_token_program` and `quote_token_program`.

Canonical AMM pool index is 0. Seeds `[pool, index=0, pump_pool_authority, base_mint, quote_mint]` where `pump_pool_authority = PDA(["pool-authority", base_mint], Pump)`. Only canonical pools earn coin-creator fees. Prefer protocol migrate over creating a non-canonical pool unless they explicitly ask.

Quote AMM with **effective** quote reserves: `pool_quote_token_account.amount + Pool.virtual_quote_reserves` (i128; 0 on all pools today; some boost pools may become non-zero). Base side is raw vault amount.

LP: `deposit` / `withdraw` charge no swap fees. `lp_supply` ignores user burns (only withdraw reduces it). Operator signs.

Boost (`init_boost`, `boost_buy_and_burn`, `toggle_boost`) is AMM-admin. Do not implement unless they ask.

Do not mix this with Metaplex Genesis bonding curves ([metaplex-agent-token](sand-workflow:metaplex-agent-token)).
