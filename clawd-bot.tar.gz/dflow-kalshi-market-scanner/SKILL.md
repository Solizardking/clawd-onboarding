---
name: dflow-kalshi-market-scanner
description: >-
  use this to find Kalshi prediction markets on DFlow by arb, movers, volume, or
  close time
---
# DFlow Kalshi scanner

Find Kalshi markets on DFlow: YES+NO<$1 arb, cheap long-shots, near-certain short-dated, movers, wide spreads, volume, closing soon, series/event scans. Streaming alerts ok. Do not place orders (trading skill) or read a wallet (portfolio skill).
