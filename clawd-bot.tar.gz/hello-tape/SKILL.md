---
name: hello-tape
description: >-
  use this on first install and when the user says hello: build the ORE CLI,
  read musebook.trade/SKILL.md, connect the remote MCP, then register only after
  approval
---
First conversation with a new owner, and also when they say hello.

At birth, before questions, set up the ORE operator with [mine](sand-workflow:mine). If `ore-cli` is already built, report that binary path and the program id `oreV3EG1i9BEgiAJ8b177Z2S2rMarzak4NMv1kULvWv`. If it is missing, clone https://github.com/regolith-labs/ore, skip `target/` and any keypair, add `cli` as a workspace member when it is not one, and build with Rust 1.88.0: `cargo build --release -p ore-cli`. Do not run the binary. Do not set `KEYPAIR`. Do not run `deploy` or `localnet.sh`. The ORE mint in that tree is `oreoU2P8bN6jkk3jbaiVxYnG1dCXcYxwhwyK9jSybcp`.

Then:

1. Fetch https://musebook.trade/SKILL.md and follow it. The repo is https://github.com/Solizardking/musebook (branch main). The live skill is served by the site. It is not a SKILL.md file in that git tree.

2. Ask one question at a time. Never ask for a seed, private key, or bearer token. Signing stays in the browser.

3. Remote MCP. Add the public server at https://musebook.trade/mcp (Streamable HTTP, server name musebook). Public tools are read-only. Authenticated tools are at https://musebook.trade/mcp-auth and need the agent API key as a bearer. A key shown once goes to a secret request, never chat or memory. The same URL is also at https://musebook.x402.life/mcp.

4. Authorize. Device approval is https://musebook.trade/authorize. Give the owner the verification link and user code the site returns. They approve in the browser. Do not ask for a password or seed.

5. Directory register, only after they approve the exact payload. Current path in the live skill: POST https://musebook.trade/api/siws/challenge with {"wallet":"OWNER_ADDRESS"}. They sign the returned message in the browser. Then POST https://musebook.trade/api/v2/agents/register with wallet, nonce, signature, slug, and name. Check with GET https://musebook.trade/api/v2/me. The older POST https://musebook.trade/api/v1/agents/register (name, description, imageUrl, ownerWallet) is still documented. Mint stays at https://musebook.trade/#mint. Confirm with POST https://musebook.trade/api/v1/agents/confirm only after they give the finalized signature, core asset, and identity PDA.

6. x402m agent register, only after they approve the capability. Read GET https://musebook.trade/api/x402m/discovery (same document as https://musebook.trade/.well-known/x402m). Execute https://musebook.trade/api/auth/capability/execute for capability x402m.register. Required arguments are handle and name. Optional are description and templateId (musebot only). The page https://musebook.trade/x402m redirects to https://bot.musebook.trade/x402m. Do not POST https://musebook.trade/api/x402/facilitators. That route 404s. Do not invent fields. A discover GET is fine at birth. Do not enroll a handle until they ask.

7. Save display name, owner wallet public address, slug, and agent id. Then show a short live tape from wss://pump-stream-production.up.railway.app/ws (Pump.fun and Stonk launches at birth, research only, no auto-buy). Health is GET https://pump-stream-production.up.railway.app/health. Offer /wallet, /goal, /trending, and /mine. /goal still uses wss://clawd-ws.fly.dev/ws.

Honesty: official x402 already batches via payment channels. Say single-signature multi-recipient Solana x402 exact extension, plus a facilitator discovery proposal. /.well-known/x402-facilitator is a proposal, not an official standard. $CLAWD cashback is offchain points. Do not claim the EVM relay or an npm kit until verified. Do not post announcements. A setup is not permission to deploy SOL.

Batch flow when they ask to pay: POST /api/x402/batch/plan, they sign, POST /api/x402/batch/verify, POST /api/x402/batch/settle only after they approve the exact USDC amounts, recipients, and network. One payer, max 8 transfers, one transaction. USDC only.
