---
name: pump-amm-trading
description: >-
  use this when trading or providing liquidity on a graduated pump.fun PumpSwap
  AMM pool
---
# PumpSwap AMM trading

After `bondingCurve.complete` / `real_token_reserves == 0`, trade and LP on PumpAMM (`pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`) via `@pump-fun/pump-sdk@1.36.0` / `@pump-fun/pump-swap-sdk@1.19.0`. Fetch `onlineSdk.fetchPool(mint)` or `canonicalPumpPoolPda(mint)`. Prefer the protocol migrate path ([pump-migrate](sand-workflow:pump-migrate)) over creating a non-canonical pool.

Quote using **effective** quote reserves: `pool_quote_token_account.amount + Pool.virtual_quote_reserves` (i128; 0 on all pools today; BuyEvent/SellEvent append the field). Base side is still raw vault amount. Slippage: 1% is `minOutput = expected * (10000 - 100) / 10000`.

- `ammBuyInstruction` — `baseAmountOut` + `maxQuoteAmountIn`
- `ammBuyExactQuoteInInstruction` — `quoteAmountIn` + `minBaseAmountOut`
- `ammSellInstruction` — `baseAmountIn` + `minQuoteAmountOut`
- LP: `ammDepositInstruction` / `ammWithdrawInstruction` (no swap fees)

Creator fees: `ammCollectCoinCreatorFeeInstruction` (fails if sharing_config). Before share-distribute on graduated coins: `transfer_creator_fees_to_pump_v2` (unified; SOL close-recreate or token ATA transfer). `ammSetCoinCreatorInstruction` / `ammMigratePoolCoinCreatorInstruction` fill `pool.coin_creator`.

Volume: two UVAs (same seeds, AMM program id). Legacy cashback remaining accounts: buy `[amm_uva_wsol_ata]`; sell `[amm_uva_wsol_ata, amm_uva]`. Claim: [pump-cashback](sand-workflow:pump-cashback). User WSOL ATA must exist before AMM claim.

Pool flags: `is_mayhem_mode`, `is_cashback_coin`, `coin_creator` (default pubkey on non-canonical). Pass both feeRecipient and buybackFeeRecipient on swaps. See [pump-program-ids](sand-workflow:pump-program-ids).

Boost flows use `Pool.virtual_quote_reserves` and are not normal trading. Operator signs every spend.
