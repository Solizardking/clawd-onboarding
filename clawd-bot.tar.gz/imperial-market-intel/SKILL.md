---
name: imperial-market-intel
description: >-
  use this for Imperial/Phoenix market data: funding, mark prices, route checks,
  Phoenix depth
---
Reads: `GET /api/v1/funding-rates`, `/mark-prices`, `/phoenix/mark-prices`, `/phoenix/depth`, `/route`. Check funding + mark, then Phoenix depth, then `/route`. Canonical symbols (`SOL`, `BTC`, `XAU`) vs Phoenix depth (`SOL`, `GOLD`).
