---
name: coinbase
description: >-
  Use when someone wants to connect a Coinbase account and trade crypto,
  eligible US stocks or futures, or pay for research with x402. Base onchain
  swaps stay on the awal CLI.
---
# Coinbase

Source checked 2026-10-02: https://www.coinbase.com/skill.md and https://docs.cdp.coinbase.com/coinbase-for-agents/skill.md (guide 0.2.3). Recheck those before treating this as current.

Two different Coinbase products. Do not mix them, and do not mix either with Solana (Jupiter, DFlow, pump.fun).

## Account (crypto, US stocks, futures)

This is https://www.coinbase.com/skill.md. Grok Bot is allowlisted. No CDP API key.

1. If Coinbase is already connected in Grok, use that connector. Connectors are account-wide.
2. Otherwise open Marketplace, search Coinbase, choose Add, and sign in. On the approval screen, pick a dedicated portfolio.
3. Remote MCP is https://agents.coinbase.com/mcp. Let the app handle OAuth. Never ask for a password, one-time code, token, or API key in chat.
4. After consent, call coinbase_portfolios_list with empty arguments. An empty list still means the connection worked. If no Coinbase tools appear, say verification is blocked. Do not call the MCP URL yourself.

Use Coinbase Wallet MCP (https://wallet-mcp.coinbase.com) only when they explicitly want an onchain agent wallet.

Trades, transfers, and conversions wait for a yes on the product, side, size, and type. Preview first. Send a fresh client_order_id. An order id is not a fill. Stocks use TICKER-QUOTE ids. Market stock orders only during the regular session. Futures use contract size and only the default portfolio.

Paid research: coinbase_x402_resources is free. coinbase_x402_fetch spends USDC on Base from the Coinbase balance, at most 5 USDC per payment. Agree a budget first. max_amount is atomic USDC (1000000 = 1 USDC) and can only lower the catalog price. Reuse the same idempotency key if the outcome is unknown.

To revoke access they open Coinbase Account, Security, Connections.

## Base onchain (awal)

Buy or sell tokens on Base through Coinbase Agentic Wallet (`npx awal@latest`) only when they want that wallet, not the account above. Auth and balance first. Confirm the pair and size. This is not Jupiter and not pump.fun.
