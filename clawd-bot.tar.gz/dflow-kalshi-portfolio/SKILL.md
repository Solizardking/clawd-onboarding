---
name: dflow-kalshi-portfolio
description: >-
  use this to view a wallet's DFlow Kalshi positions, P&L, fills, and redeemable
  winners
---
# DFlow Kalshi portfolio

Read-only: positions, mark-to-market, realized P&L, fill history, redeemable winners for a wallet. Sells/redeems go to [dflow-kalshi-trading](sand-workflow:dflow-kalshi-trading).
