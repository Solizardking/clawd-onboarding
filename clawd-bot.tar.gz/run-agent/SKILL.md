---
name: run-agent
description: >-
  use this when registering a Metaplex executive profile, delegating or revoking
  Execute on an agent asset
---
# Run a Metaplex agent (executive delegation)

Let an off-chain executive sign via Core Execute on a registered agent's Asset Signer PDA. Docs: https://www.metaplex.com/docs/agents/run-an-agent

SDK: `@metaplex-foundation/mpl-agent-registry` v0.2.0+ with `mplAgentIdentity()` and `mplAgentTools()`. Never load secret keys. Operator (asset owner) confirms every delegate or revoke.

Need a registered agent first.

## Flow

1. **Register executive** (once per wallet): `registerExecutiveV1({ payer })`. PDA `["executive_profile", authority]`. Second call with the same wallet fails.
2. **Delegate** (per agent, owner only): `delegateExecutionV1({ agentAsset, agentIdentity, executiveProfile })`. Executive can then pass **any** instruction through Execute. Delegate only to operators they trust.
3. **Verify**: `findExecutionDelegateRecordV1Pda` + `getAccount` → `exists`.
4. **Revoke**: `revokeExecutionV1` — owner **or** executive. Closes the record, refunds rent to `destination`. Stops future AgentIdentity Execute. Does **not** unwind SPL approvals or other downstream state.

Owner can Execute directly without an executive (Core validates owner). To drop an SPL approval after revoke, `revokeTokenDelegate` through Core `execute`.

Default in this bot: do not enable unsigned free spend. Delegation is an explicit, consequential yes.
