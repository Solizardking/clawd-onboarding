---
name: pump-analytics
description: >-
  use this when quoting pump.fun price impact, graduation progress, or
  bonding-curve market cap
---
# Pump.fun analytics

Offline math in `@pump-fun/pump-sdk` plus `OnlinePumpSdk` fetchers. No RPC needed if you already have global, feeConfig, and bondingCurve.

- `calculateBuyPriceImpact` / `calculateSellPriceImpact` → `impactBps`, `outputAmount`, prices before/after
- `getGraduationProgress(global, bondingCurve)` → `progressBps` 0–10000, `isGraduated`, tokens remaining, SOL accumulated
- `getTokenPrice` — buy/sell per whole token (1e6 raw units) and market cap
- `getBondingCurveSummary` — one snapshot

Online: `fetchBondingCurveSummary(mint)`, `fetchGraduationProgress`, `fetchTokenPrice`, `fetchBuyPriceImpact(mint, solAmount)`, `fetchSellPriceImpact(mint, tokenAmount)`, `isGraduated`, `getTokenBalance`.

Use BN. Do not treat analytics as a buy signal. Pair with rug-check before any trade the operator requested.
