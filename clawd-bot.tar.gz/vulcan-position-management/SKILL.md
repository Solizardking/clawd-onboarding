---
name: vulcan-position-management
description: 'use this to list, show, close, or reduce Phoenix positions and attach TP/SL'
---
List, show, close, reduce Phoenix positions; attach/cancel TP/SL. Live close/reduce needs confirm + `--yes` and verify after. Match position side.
