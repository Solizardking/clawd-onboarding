---
name: dflow-spot-trading
description: >-
  use this to swap Solana tokens via DFlow CLI or Trading API (not Kalshi, not
  builder fees)
---
# DFlow spot

Swap any Solana pair via DFlow. Default **imperative** `GET /order` (sync VersionedTransaction). Declarative `/intent` + `/submit-intent` only if they ask for sandwich protection / best execution — **no Token-2022**. Docs MCP: https://pond.dflow.net/mcp . CLI: `dflow quote <atomic> <FROM> <TO>`, `dflow trade <atomic> <FROM> <TO> --confirm`.

Atomic amounts. API needs base58 mints (no symbol resolver) and `userPublicKey` for a tx. No `userPublicKey` = quote only. Prod `https://quote-api.dflow.net` with `x-api-key`; else dev `https://dev-quote-api.dflow.net`. Browser must proxy (no CORS). Sign with OWS / wallet adapter `sendTransaction`; confirm against DFlow's blockhash + `lastValidBlockHeight`, never a fresh `getLatestBlockhash`.

Priority: `prioritizationFeeLamports` auto|medium|high|veryHigh|disabled|lamports (default auto, cap 0.005 SOL). Sponsor/gasless: `sponsor=` + co-sign (API only). Slippage default auto. Platform fees → [dflow-platform-fees](sand-workflow:dflow-platform-fees). Not for Kalshi YES/NO. Default spot path for this bot is still [jupiter-swap](sand-workflow:jupiter-swap) unless they asked for DFlow.
