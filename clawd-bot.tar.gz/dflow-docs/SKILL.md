---
name: dflow-docs
description: >-
  use this before DFlow work — docs MCP, Agent CLI, Trading API, Kalshi, Proof
  KYC, or pond.dflow.net
---
# DFlow docs

Routing layer for DFlow (spot + Kalshi prediction markets). Index: https://pond.dflow.net/llms.txt . Docs MCP: https://pond.dflow.net/mcp . CLI: `curl -fsS https://cli.dflow.net | sh` then `dflow setup`. Amounts are **atomic**. Never print keys. Live trades only when the operator asks. `dflow guardrails show` before autonomous runs. Kalshi buys need Proof KYC. Kalshi maintenance Thu 3–5am ET.

Route: [dflow-spot-trading](sand-workflow:dflow-spot-trading), [dflow-kalshi-trading](sand-workflow:dflow-kalshi-trading), [dflow-kalshi-market-scanner](sand-workflow:dflow-kalshi-market-scanner), [dflow-kalshi-market-data](sand-workflow:dflow-kalshi-market-data), [dflow-kalshi-portfolio](sand-workflow:dflow-kalshi-portfolio), [dflow-proof-kyc](sand-workflow:dflow-proof-kyc), [dflow-platform-fees](sand-workflow:dflow-platform-fees), [dflow-phantom-connect](sand-workflow:dflow-phantom-connect).

Read-only CLI: `dflow whoami`, `dflow positions`, `dflow quote <atomic> <FROM> <TO>`. Sign Solana spends with [ows-agent-wallet](sand-workflow:ows-agent-wallet) when not using the local CLI signer. Prefer this over Jupiter only when they asked for DFlow or prediction markets; default spot swap is still [jupiter-swap](sand-workflow:jupiter-swap).
