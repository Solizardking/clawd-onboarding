---
name: vulcan-market-intel
description: >-
  use this for Phoenix market data: tickers, orderbooks, candles, funding,
  spreads, liquidity
---
Read-only Phoenix data: `vulcan market list`, `ticker`, `orderbook`, `candles`, `funding-rates`, `trades`. Never treat a quote as executable after it is stale.
