---
name: pump
description: >-
  use this when the user wants pump.fun or Stonk launches at birth from the
  Railway pump stream
---
Use when the operator wants pump.fun or Stonk launches at birth, runs /pump, or asks for the live launch feed. This is research only. Do not auto-buy.

## Birth feed

Origin: https://pump-stream-production.up.railway.app/
WebSocket: wss://pump-stream-production.up.railway.app/ws
Health: GET https://pump-stream-production.up.railway.app/health

No auth and no subscribe frame. Send nothing. The page client connects to `/ws` on that host.

1. GET /health. If it is not ok, say the stream is down. Do not invent launches.
2. Open the WebSocket. First frames are `status`, then recent `token-launch` events (the client marks those with `replay`), then live events.
3. Keep `token-launch` rows. Apply `token-update` onto the matching launch. Trades, migrations, and `pool-create` are a separate tape.
4. Show the latest launches, newest first. One short list.

Each launch row: name, symbol, mint, platform (`pumpfun` or `stonkfun`), creator, time, and marketCapSol when present. Pump cards are confirmed on their RPC. Stonk cards come from the public launch ledger (the health payload polls about every 15s).

Dedup with mint plus pool when a pool is present.

## One mint

GET https://pump-stream-production.up.railway.app/api/token/{mint}?platform=pumpfun

Add `pool` when the launch has one. Stonk uses `platform=stonkfun`. Read-only first. Do not build a transaction until they pick an action and a size.

POST https://pump-stream-production.up.railway.app/api/analyze/{mint} with the same query only when they ask for CLAWD analysis. It can take up to a minute. If analysis is not configured, say so. Do not invent a verdict.

## Trade

Buys and sells stay on the existing pump and Jupiter paths. Sign on their machine. Never snipe the stream.

The older relay at wss://clawd-ws.fly.dev/ws is still /goal. Use this Railway feed for launches at birth.
