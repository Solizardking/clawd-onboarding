---
name: imperial
description: >-
  use this for Imperial perps routing, Phoenix-routed perps, profile funding, or
  Telegram bot trading on Imperial
---
# Imperial — perps router

Entry skill for Imperial perpetual routing on Solana (Phoenix preferred, also Flash, Jupiter, GMTrade). Source: https://github.com/Solizardking/skills (`imperial/*`).

`IMPERIAL_API_KEY` / `IMPERIAL_JWT` via secret-request — never log. Track `profileIndex`. Inspect `success` on `POST /api/v1/mobile/orders` even when HTTP 200. Default venue Phoenix (`underwriter=2`). Do not treat a Telegram webhook as a TWAP/grid engine.

Route: [imperial-trade-execution](sand-workflow:imperial-trade-execution), [imperial-risk-management](sand-workflow:imperial-risk-management), [imperial-margin-operations](sand-workflow:imperial-margin-operations), [imperial-market-intel](sand-workflow:imperial-market-intel), [imperial-portfolio-intel](sand-workflow:imperial-portfolio-intel), [imperial-position-management](sand-workflow:imperial-position-management), [imperial-tpsl-management](sand-workflow:imperial-tpsl-management), [imperial-twap-execution](sand-workflow:imperial-twap-execution), [imperial-grid-trading](sand-workflow:imperial-grid-trading), [imperial-execution-modes](sand-workflow:imperial-execution-modes). Index: [imperial-skills-index](sand-workflow:imperial-skills-index).
