---
name: liquidity-planner
description: >-
  use this when planning Solana liquidity, LP around a swap or launch, or
  choosing a venue by depth
---
# Liquidity planner (Solana)

Plan LP around a trade or launch: venue depth (GeckoTerminal / DexScreener / PumpSwap effective quote reserves), price impact, fee tier, IL. For pump coins still on the curve, LP is N/A until graduation. Spot execution still [jupiter-swap](sand-workflow:jupiter-swap) or [pumpfun-trading](sand-workflow:pumpfun-trading). Confirm every on-chain LP tx.
