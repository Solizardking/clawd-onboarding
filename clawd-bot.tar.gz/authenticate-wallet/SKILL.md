---
name: authenticate-wallet
description: use this to sign in to Coinbase Agentic Wallet via awal email OTP (Base USDC)
---
# Authenticate Coinbase Agentic Wallet (awal)

Sign in via email OTP before Base send/trade/fund. Docs: https://docs.cdp.coinbase.com/llms.txt

```bash
npx awal@latest status
npx awal@latest auth login <email>        # flowId
npx awal@latest auth verify <flowId> <otp>
npx awal@latest address
npx awal@latest balance
npx awal@latest show
```

`--json` on all commands. Ask the user for the 6-digit code. This wallet is **USDC on Base**, not Solana. Pump trades still need [wallet](sand-workflow:wallet) OWS.
