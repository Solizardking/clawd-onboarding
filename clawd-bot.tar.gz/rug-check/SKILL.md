---
name: rug-check
description: >-
  use this when checking whether a Solana mint is safe to buy or launch beside
  (authorities, holders, rug score)
---
# Rug-check (Solana token safety)

Read-only diligence before swapping into or launching beside a mint. Never signs.

On-chain (authoritative): mint authority, freeze authority, top-holder concentration via RPC (`getAccountInfo`, `getTokenLargestAccounts`). Revoked (null) mint/freeze is the safe state.

Heuristic: RugCheck.xyz score. If score and chain disagree, trust chain.

Verdicts: CLEAN / CAUTION / RUGGABLE. Flag: mint still active, freeze active, unlocked LP, top-10 >30% elevated / >60% dangerous (LP/CEX/vesting can look like whales — check owners).

Never auto-trade off a clean result. Not financial advice. Optional `HELIUS_API_KEY` / `SOLANA_RPC_URL` for rate limits.
