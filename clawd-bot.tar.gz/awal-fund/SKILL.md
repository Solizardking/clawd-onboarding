---
name: awal-fund
description: use this to fund the Coinbase awal wallet via Coinbase Onramp (USDC on Base)
---
# Fund Coinbase Agentic Wallet

Onramp USDC on **Base** via Coinbase Pay. Must be authenticated. `npx awal@latest show` → Fund. Methods: Apple Pay, Coinbase, card (instant), bank (1–3 days). Or send USDC on Base to `npx awal@latest address`. Then `npx awal@latest balance`. For Solana SOL/USDC on-ramp prefer MoonPay / OWS fund, not this.
