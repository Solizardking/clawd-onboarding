---
name: vulcan-error-recovery
description: >-
  use this on failed Vulcan CLI/MCP calls, tx failures, auth, rate-limit, or
  strategy recovery
---
On Vulcan/Phoenix errors: do not blind-retry live txs. Verify account, order, position, and history first. Pair with [vulcan](sand-workflow:vulcan). Categorize auth/config/API/network/rate-limit vs on-chain fail.
