---
name: solgpt-pump-stream
description: >-
  use this when ingesting the live pumpfun stream (clawd-ws relay) for new token
  launches
---
# Live pumpfun stream

Canonical live ingest for pump.fun agents is the live pumpfun stream (Clawd relay). It is a **new-token launch feed**, not a trade or migration bus. Prefer the `/pump` skill when the operator wants a snapshot or to interact with coins.

## Endpoints

- WebSocket (use this): `wss://clawd-ws.fly.dev/ws`
- Dashboard origin: `https://clawd-ws.fly.dev/`
- Health: `GET https://clawd-ws.fly.dev/health` (JSON, `cache-control: no-store`)
- Optional analyze: `POST https://clawd-ws.fly.dev/api/analyze/{mint}`
- Env fallbacks: `NEXT_PUBLIC_PUMP_WS_URL` || `NEXT_PUBLIC_CLAWD_WS_URL` || `wss://clawd-ws.fly.dev/ws`
- Do **not** use an Express `/ws` tracker proxy (HTTP `GET /ws` is HTML, no upgrade)

## Auth

- WebSocket: **none**. No API key, no wallet header, no query string. Open and listen. Send nothing.

## Connect

1. Optional: `GET /health`. Useful fields: `status`, `solana`, `clients`, `totalLaunches`, `totalClaims`, `enrichLaunches`, `uptime`. If it fails, say the relay is down; do not invent launches.
2. Open `wss://clawd-ws.fly.dev/ws`. No subscribe frame.
3. First frames: current `status`, then **backfill** of recent launches (~50–60 `token-launch`). Treat that burst as history (filter `time` vs now, or skip until a post-connect `heartbeat`).
4. Then live events plus `status` ~every 10s and `heartbeat` ~every 15s.
5. On close or error, reconnect with exponential backoff starting at 1s, cap 30s.

## Event types (real field names)

Parse `JSON.parse(message.data)`. Branch on `type`.

**`status`** (connect + ~10s): `connected`, `uptime`, `totalLaunches`, `githubLaunches`, `totalClaims`, `clients`. Liveness only.

**`heartbeat`**: `{ type, ts }` epoch-ms. Keepalive only.

**`token-launch`** (primary):

- `signature` — often the **mint**, not a tx id. Dedup with `mint || signature`.
- `time` ISO timestamp
- `name`, `symbol`, `description`
- `metadataUri`, `imageUri`
- `mint`, `creator`
- `isV2`, `hasGithub`, `githubUrls`
- `marketCapSol`
- `website`, `twitter`, `telegram`

**`token-enriched`**: overlay keyed by `mint`. Client renders `marketCapUsd`, `logoUri`, `priceUsd`, `holders`. Merge; do not treat as a second launch.

**`fee-claim`**: in the relay types, often idle (`totalClaims` may be 0). Fields: `txSignature`, `slot`, `timestamp`, `claimerWallet`, `tokenMint`, `tokenName`, `tokenSymbol`, `amountSol`, `amountLamports`, `claimType`, `isCashback`, `programId`, `claimLabel`. `claimType` enum: `collect_creator_fee | claim_cashback | collect_coin_creator_fee | distribute_creator_fees | transfer_creator_fees_to_pump | claim_social_fee_pda`.

Not on this stream: per-trade fills, bonding-curve %, migrations. Those need on-chain logs or the Pump SDK.

## What to do with events

- `token-launch` → short alert: name, symbol, mint, creator, `marketCapSol`, `isV2`, socials/GitHub. Do not auto-buy or auto-launch.
- `token-enriched` → overlay USD mcap / holders / logo.
- `fee-claim` → fee signal if it starts firing; still do not auto-collect.
- `status` / `heartbeat` → liveness.

This feed is **observe-only** until the operator picks a coin. Launch, buy, sell, and fee collection are separate skills and need an explicit go-ahead.

## Optional analysis

Only when the operator asks: `POST https://clawd-ws.fly.dev/api/analyze/{mint}`. If analyze returns 500 / credits denied, say so. Do not invent a research writeup.
