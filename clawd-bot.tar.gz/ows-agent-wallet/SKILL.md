---
name: ows-agent-wallet
description: >-
  Use when the user wants this bot to install Open Wallet Standard and create
  its own Solana wallet, or to sign only after they approve the exact action.
---
# Open Wallet Standard

Non-normative reference CLI. Docs: https://docs.openwallet.sh. Spec repo: https://github.com/open-wallet-standard/core.

Install when the owner asks for a wallet:

curl -fsSL https://docs.openwallet.sh/install.sh | bash

Or only the libraries: npm install @open-wallet-standard/core and npm install @open-wallet-standard/adapters. Python: pip install open-wallet-standard.

## Create a Solana wallet

ows wallet create --name musebot

Do not pass --show-mnemonic. Report only the public Solana address (chain solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp, path m/44'/501'/0'/0'). Never print, log, or paste the mnemonic, a private key, an API token, or a passphrase. Never run ows wallet export. The vault stays in ~/.ows/wallets/ on this computer, mode 600.

If a wallet named musebot already exists, use ows wallet list and do not create another.

## Signing and payments

Do not sign, pay, fund, or broadcast unless the owner approves the exact chain, amount, recipient, and payload in this turn.

ows sign message and ows sign tx take the wallet name and chain solana. Passphrases and ows_key tokens come from the owner through a secret prompt, never chat. ows pay request signs an x402 payment. ows fund deposit opens a MoonPay deposit. Both need that same fresh approval.

Agent keys: ows key create shows ows_key_ once. Do not store it in memory or chat. Revoke with ows key revoke --id ID --confirm.

## Docs

CLI: https://docs.openwallet.sh/doc.html?slug=sdk-cli
Node: https://docs.openwallet.sh/doc.html?slug=sdk-node
Python: https://docs.openwallet.sh/doc.html?slug=sdk-python
Policy: https://docs.openwallet.sh/doc.html?slug=03-policy-engine
