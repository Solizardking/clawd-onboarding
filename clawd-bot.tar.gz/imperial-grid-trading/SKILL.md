---
name: imperial-grid-trading
description: >-
  use this for Imperial/Phoenix grid: ladder layout, venue pin, replacement,
  runner boundary
---
Imperial can place single orders; grid maintenance is a strategy. Design bounds, per-level size, Phoenix pin, replacement after fills. Live grids need a dedicated runner with state. Document that when the ask comes via Telegram.
