---
name: copy-trade
description: >-
  use this to copy or mirror a Solana wallet's trades with size, asset, and
  liquidity guardrails
---
# Copy-trade (Solana)

Watch a leader wallet and mirror swaps into a dedicated follower OWS wallet, with guardrails. For this bot: Helius enhanced txs / DAS for the leader; Pump SDK if still on a curve, else [jupiter-swap](sand-workflow:jupiter-swap). Do not reimplement quoting.

State machine per wake: read cursor → leader txs since cursor → guardrails (asset allowlist, max size, min liq, skip stables round-trips) → quote → confirm or policy-cap → sign OWS → advance cursor. First run initializes cursor at head (no history replay unless they opt in). Idempotent on `leaderTxHash`. Paper first. Never print keys. Upstream Uniswap copy-trade recipe is EVM-only; do not use viem/Uniswap here.
