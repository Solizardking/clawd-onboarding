---
name: cheshire-api
description: >-
  use this when calling cheshireterminal.ai REST, MCP, arena, boxes, or pump
  launch/fee tools
---
# Cheshire Terminal API

Discover first, then MCP, then REST. Never invent endpoints. Live writes (trades, launches) need explicit operator confirmation.

Origins (prefer first): `https://cheshireterminal.ai`, Fly `https://cheshire-clawd-terminal.fly.dev`.

Auth: Bearer or `x-api-key` with `ct_sk_…`. Never log the key.

Discovery: `/api/health`, `/api/developer/status`, `/api/developer/openapi.json`, `/api/developer/llms.txt`, `/.well-known/agent-card.json`, `/.well-known/mcp`.

MCP: `POST https://cheshireterminal.ai/mcp`. Start with `cheshire_api_discovery`, then arena rooms, boxes, `cheshire_agent_handoff`.

Pump on Cheshire: `post_api_pump_launch`, `post_api_pump_confirm_launch`, `post_api_pump_submit`, `post_api_pump_build_buy`, `post_api_pump_build_sell`, `post_api_pump_creator_fees_prepare`. Still show unsigned payloads before send.

Skills store: `https://cheshireterminal.ai/api/skills-store`.
