---
name: sell
description: use this when the user runs /sell to sell a Solana or pump.fun token
---
# /sell — sell a token

Use when they run `/sell` or `/sell <mint> [amount|all]`. Wallet first. Confirm size once.

- Still on the curve → [pumpfun-trading](sand-workflow:pumpfun-trading) `sell_v2`.
- Graduated → [jupiter-swap](sand-workflow:jupiter-swap) (input = the mint, output = SOL or USDC).
- Perps close → [vulcan-position-management](sand-workflow:vulcan-position-management) / [imperial-position-management](sand-workflow:imperial-position-management), not this.

Sign with OWS. Report signature. No revenge sells after a beach.
