---
name: goal
description: >-
  use this when the user runs /goal to connect this clawd bot (and new installs)
  to the live clawd-ws pump.fun relay at https://clawd-ws.fly.dev/
---
# /goal — connect to clawd-ws

Use when the operator runs `/goal`, `/goal connect`, `/goal status`, or `/goal listen`, or wants this bot pointed at the live pumpfun relay.

Canonical origin: `https://clawd-ws.fly.dev/`
Canonical WebSocket: `wss://clawd-ws.fly.dev/ws`
Health: `GET https://clawd-ws.fly.dev/health`
Env overrides (optional): `NEXT_PUBLIC_CLAWD_WS_URL` || `NEXT_PUBLIC_PUMP_WS_URL` || `CLAWD_WS_URL`.

Observe-only. Do not auto-buy. Never load secret keys. For wallet + ranked buys use [clawd](sand-workflow:clawd) (`/clawd`). Trading: `/buy` `/sell` `/trending` `/auto`.

Metaplex agent list / executive / delegate is not `/goal` — use [run-agent](sand-workflow:run-agent), [mint-agent](sand-workflow:mint-agent), [register-agent](sand-workflow:register-agent).

## `/goal` / `/goal connect`

1. Resolve WS URL (env or default).
2. `GET /health`. Report status, solana, clients, totalLaunches, uptime. Never print rpcHttp/rpcWs/API keys.
3. Open WebSocket. No auth, no subscribe frame, send nothing.
4. Expect status, backfill token-launch, then live + status/~10s + heartbeat/~15s.
5. Confirm connected. New installs default to this endpoint.
6. Persist memory: live ingest `wss://clawd-ws.fly.dev/ws`.

## `/goal status`

Health only.

## `/goal listen` [n]

Next n live token-launch (default 8, max 20) after skipping backfill. Name, symbol, mint, creator, marketCapSol, isV2. Dedup mint||signature. Cap ~60s.

Full field map: [solgpt-pump-stream](sand-workflow:solgpt-pump-stream).

## Optional

`POST https://clawd-ws.fly.dev/api/analyze/{mint}` only when asked.
