---
name: dflow-kalshi-market-data
description: >-
  use this for Kalshi orderbook, trades, candles, or live WebSocket data on
  DFlow
---
# DFlow Kalshi market data

Orderbook, trades, top-of-book, candles, forecast-percentile history, in-game live data. REST snapshots, historical ranges, or WebSocket. Read-only. Not for discovery, orders, or wallet P&L.
