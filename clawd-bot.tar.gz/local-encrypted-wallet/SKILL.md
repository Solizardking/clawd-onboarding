---
name: local-encrypted-wallet
description: >-
  use this when the operator wants a DIY AES-256-GCM Solana keypair on their
  device instead of OWS or Privy
---
# Local encrypted agent wallet (DIY)

Fallback if the operator wants a **self-built** keystore instead of OWS or Privy. Prefer `ows-agent-wallet` first.

On **their device only**: generate a Solana Keypair, wrap the 64-byte secret with AES-256-GCM (random 12-byte IV, 16-byte auth tag, key from scrypt/Argon2id of a passphrase they type — never store the passphrase). One keypair file per agent. Never log secrets. Never copy the file to this agent's computer.

Sign pump.fun VersionedTransactions locally. Default: confirm each spend. "Autonomous" only after they set a policy (max lamports, mint allowlist, stop-loss). Devnet first (`https://api.devnet.solana.com`) until they say mainnet.

Optional JupiterAdapter for swaps. Multi-agent: separate files and state. Observe → Think → Act loop is a strategy layer, not a reason to skip confirm.

If they also want OWS, migrate: create `ows wallet create` and stop using the DIY file.
