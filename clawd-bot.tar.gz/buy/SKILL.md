---
name: buy
description: use this when the user runs /buy to purchase a Solana or pump.fun token
---
# /buy — buy a token

Use when they run `/buy`, `/buy <mint> <amount>`, or “buy this”. Need a Solana wallet first ([wallet](sand-workflow:wallet)). Rug-check ([rug-check](sand-workflow:rug-check)) unless they already cleared it this turn.

1. Resolve mint (from `/pump`, `/trending`, or pasted base58).
2. Curve vs graduated ([pump-analytics](sand-workflow:pump-analytics)).
3. Size in SOL or tokens. Confirm once. Operator confirms spend.
4. **Bonding curve** → [pumpfun-trading](sand-workflow:pumpfun-trading) `buy_v2` / `buy_exact_quote_in_v2`.
5. **Graduated / any DEX mint** → [jupiter-swap](sand-workflow:jupiter-swap) `/order` + `/execute` (partial OWS sign). DFlow only if they asked ([dflow-spot-trading](sand-workflow:dflow-spot-trading)).
6. Base-chain “buy $5 ETH” is [awal-trade](sand-workflow:awal-trade), not this.

Never snipe the live stream. Show signature + Solscan.
