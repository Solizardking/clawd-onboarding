---
name: zk
description: >-
  use this for Solana ZK: nullifiers, Groth16, Light compressed state, or Clawd
  attestations
---
# ZK on Solana (Clawd / Light)

Nullifier (once-only), Groth16, Light compressed state. Observer-first: health/catalog ok; build ix dry-run; sign+send only delegated. Never double-claim. Related: Automaton `zk-primitives`, Cheshire zk-omni. Program work stays unsigned until OWS confirms.
