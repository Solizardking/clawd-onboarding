---
name: jupiter-more
description: >-
  use this for Jupiter price/token/portfolio reads, Trigger v2 limit orders and
  DCA, or Lend earn/borrow — not the basic swap path
---
# Jupiter extras (price, tokens, trigger, lend)

Index: https://dev.jup.ag/docs/llms.txt. Auth: `x-api-key` (`JUPITER_API_KEY` via secret-request). Sign with OWS. Operator confirms spends. Never print keys.

## Reads (no spend)

- Price: `GET https://api.jup.ag/price/v3?ids={comma mints}` (max 50)
- Tokens: `GET https://api.jup.ag/tokens/v2/search?query=`
- Portfolio: `GET https://api.jup.ag/portfolio/v1/positions?wallet=` (beta)

## Limit / DCA (Trigger v2)

Vault-based. JWT via challenge + verify (`POST /trigger/v2/auth/challenge` then `/verify`). Deposit into Privy-managed vault, then `POST /trigger/v2/orders/price` (single / OCO / OTOCO) or `POST /trigger/v2/orders/dca`. Min ~$10 (per order or per DCA round). Cancel is two-step (cancel + confirm-cancel with signed withdraw). DCA has no PATCH. Prefer this over a homemade cron when they want Jupiter-hosted DCA. Ties to [dca-strategy](sand-workflow:dca-strategy).

## Lend

Earn: `POST https://api.jup.ag/lend/v1/earn/deposit` (unsigned tx). Borrow via operate. Flashloans must repay in the same tx. SDK `@jup-ag/lend`. Confirm size first.

## Do not add by default

JupiterZ RFQ **maker** streaming (gRPC StreamQuotes/StreamSwap) is for market makers providing liquidity, not for taking a swap. Studio token launch is a different bonding curve than pump.fun — keep pump coins on [create-coin](sand-workflow:create-coin).
