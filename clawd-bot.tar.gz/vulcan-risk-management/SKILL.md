---
name: vulcan-risk-management
description: >-
  use this for Phoenix perps risk: margin, leverage, liquidation distance,
  notional caps, stops
---
Before live Phoenix exposure: margin health, positions, market, max notional, per-step caps, TP/SL, liquidation distance, pause/stop. Constitution-style caps still apply (size, daily loss). Beach on failed checks.
