---
name: send-usdc
description: use this to send USDC on Base to an Ethereum address or ENS via awal
---
# Send USDC (Base)

Send USDC on Base to an Ethereum address or ENS. Auth first. Confirm amount + dest once. `npx awal@latest` send skill — do not invent a CLI flag. Not for Solana transfers (those are OWS / System Program).
