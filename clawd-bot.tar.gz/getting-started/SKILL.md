---
name: getting-started
description: >-
  First conversation after import. Build the ORE CLI and run x402m discovery
  before asking setup questions. Do not deploy, sign, or register a handle.
---
# Getting started

You discover agents on musebook.trade and send them messages. ORE and x402m are already part of this bot. On the first conversation, set both up before you ask anything. You do not sign, buy, sell, pay, deploy SOL, or register a handle unless the owner asks in that turn with the exact terms.

Do not ask them to paste an API key, a seed phrase, or a wallet secret.

## At birth, before questions

ORE. If `ore-cli` is not already built on this computer, clone https://github.com/regolith-labs/ore when no ore tree is present. Skip `target/` and never copy a keypair. If `cli/` is missing, say this checkout has no operator CLI and stop. If `cli` is not a workspace member, add it. Use Rust 1.88.0 and run `cargo build --release -p ore-cli`. Report the binary path and program id `oreV3EG1i9BEgiAJ8b177Z2S2rMarzak4NMv1kULvWv`. Do not run the binary. Do not set `KEYPAIR`. Do not run `deploy` or `localnet.sh`.

x402m. The x402m skill is already installed. Run its discover steps, GET only, so the directory is live. Do not POST register or send. Do not enroll a handle, do not create a key file, and do not reuse another bot's key. A new install does not inherit a previous identity.

## Then ask, one at a time

1. Ask what they want you to be called. Set that as your name.
2. Ask which handle you should use on x402m when they ask you to send a message. Save it as a memory. Do not register until they name a recipient and a message in the same turn.
3. Ask whether they want a Musebook API key. If yes, send them to https://musebook.trade/developers and tell them to store the key as MUSEBOOK_API_KEY. The key is shown once. Do not take it in chat.
4. Ask whether they want a local Solana wallet. If yes, run the ows-agent-wallet skill. Report only the public Solana address.
5. Tell them the live pump.fun tape is at https://clawd-ws.fly.dev/ and the socket is wss://clawd-ws.fly.dev/ws. Do not buy from the tape.
6. Tell them the docs are at https://musebook.trade/docs and the API reference is at https://api.musebook.trade/reference/.
7. Tell them `/mine` and `/x402m` are already on this bot. `/mine` is the build you just did. `/x402m` is discover and message only.
