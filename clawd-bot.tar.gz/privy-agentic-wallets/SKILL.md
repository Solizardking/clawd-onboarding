---
name: privy-agentic-wallets
description: >-
  use this when pregenerating Privy Solana wallets, adding agent signers, or
  running server-side pump.fun txs under Privy policies
---
# Privy agentic wallets

Use Privy when the operator wants **pregenerated** or **server-side** Solana wallets, not a local keyfile. Keys stay in Privy; the operator can export to their device with a valid user access token. Never put `appSecret` in chat or in the template.

Docs:
- Pregenerate: https://docs.privy.io/recipes/pregenerate-wallets
- Agentic: https://docs.privy.io/recipes/agent-integrations/agentic-wallets
- Server-side user wallets: https://docs.privy.io/recipes/wallets/server-side-user-wallets
- User + server signers: https://docs.privy.io/recipes/wallets/user-and-server-signers
- Solana policies: https://docs.privy.io/controls/policies/example-policies/solana
- Solana send: https://docs.privy.io/wallets/using-wallets/solana/send-a-transaction

Need `appId` + `appSecret` from the operator (secret-request, not paste). `PrivyClient` from `@privy-io/node`.

## Paths

**A. Pregenerate (airdrops, web2 import, assets before first login)**

`privy.users().create({ linked_accounts, wallets: [{ chain_type: 'solana', wallet_index: 0, policy_ids, additional_signers }], create_direct_signer: true })`

Existing user: `privy.users().pregenerateWallets(did, { wallets: [{ chain_type: 'solana', wallet_index: 0 }], create_direct_signer: true })`.

On first login the wallet appears; they can export with a valid access token.

**B. User-owned, user in the loop (server executes, user JWT required)**

1. Register JWKS in Privy Dashboard
2. `users().create` with `custom_auth` user id
3. `wallets().create({ chain_type: 'solana', owner: { user_id }, policy_ids })`
4. Frontend sends user access token; set `authorizationContext.user_jwts`
5. `privy.wallets().solana()` send — SDK signs with the user key

**C. Agentic / app signer (trading bot while user is offline)**

1. `openssl` P-256 app authorization key; register public key as a 1-of-1 key quorum; **private PEM stays on the operator's server, never in chat**
2. Optional Solana policy: allowlist Pump + ComputeBudget + System Program, SOL transfer caps, time windows, DENY `exportPrivateKey` unless they asked for export-to-device
3. After login, `addSigners` with `signerId` = quorum id and `policyIds`
4. App-initiated Solana txs via Node SDK / REST with `privy-authorization-signature`

Prefer **C with a tight Solana policy** for pump.fun agents. Prefer **OWS** (`ows-agent-wallet`) when they said keys on their device only.

## Solana policy starter (pump.fun)

Allowlist program IDs: Compute Budget, System Program, Pump `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`, Pump AMM `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`, Pump Fees `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ`. Cap SOL transfers. ALTs are not resolved by Privy address policies — keep allowlisted accounts in static keys.

Export-to-device: only with user JWT and an explicit operator yes. Default policy DENY `exportPrivateKey`.

There is no Privy Grok Bot connector today. Use the Node SDK on the operator's backend.
