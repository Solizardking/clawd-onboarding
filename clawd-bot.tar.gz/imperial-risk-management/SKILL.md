---
name: imperial-risk-management
description: >-
  use this for Imperial perps risk: profile funding, exposure, venue, margin
  headroom
---
Before any live Imperial trade: `/mobile/balances`, `/positions`, `/funding-rates` + `/route`, then confirm notional, side, venue, `profileIndex`. Route check is not a liquidation guarantee. Show existing same-symbol exposure before adding.
