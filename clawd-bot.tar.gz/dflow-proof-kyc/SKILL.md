---
name: dflow-proof-kyc
description: use this to KYC a Solana wallet with DFlow Proof or to gate Kalshi buys
---
# DFlow Proof KYC

Stripe Identity under the hood. Gate app features or complete mandatory verification for Kalshi buys. Redirect `dflow.net/proof`. Handle `unverified_wallet_not_allowed` / `PROOF_NOT_VERIFIED`. Not age gating, not geoblock, not spot (spot needs no KYC). Never collect ID docs in chat.
