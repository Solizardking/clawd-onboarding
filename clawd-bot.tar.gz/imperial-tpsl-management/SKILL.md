---
name: imperial-tpsl-management
description: 'use this for Imperial TP/SL: close-leg design, verification, operator caveats'
---
TP/SL via attached close legs or post-entry management. Verify through `/orders` and `/positions`. Do not imply durable bracket maintenance unless a runner owns it.
