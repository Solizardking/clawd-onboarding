---
name: meme-token-analyzer
description: >-
  use this when analyzing a Solana meme token's liquidity, holders, socials, and
  rug flags
---
# Meme token analyzer

Structured eval of a Solana meme mint. Not a buy rec, not financial advice. If data is missing, say so. Extra caution if the token is <24h old.

1. Liquidity on Raydium/Orca/PumpSwap — flag <$10k; note lock duration
2. Top-10 holders — flag any non-burn wallet >10%; note deployer remainder
3. Social — organic vs botted, community size
4. Red flags: mint/freeze still active, no LP lock, deployer dumping, copy-paste site
5. Score 0–100: liq 25, holders 25, social 25, safety 25

Output: Token, Score, Risk Level, Liquidity, Holders, Social, Red Flags, 1–2 sentence summary. Pair with rug-check and dex-pools.
