---
name: jupiter-build
description: >-
  use this when building a custom Jupiter swap with GET /swap/v2/build (Metis
  instructions, own landing or tx.jup.ag)
---
# Jupiter Swap V2 — build (Metis instructions)

Use when they need **raw instructions** (extra CPI, memo, custom CU, Jito). Metis only. No Jupiter swap fee. **Cannot** use `/execute`. Docs: https://developers.jup.ag/docs/swap/build/index.md

`GET https://api.jup.ag/swap/v2/build?inputMint=&outputMint=&amount=&taker=` plus `x-api-key`.

Returns `setupInstructions`, `swapInstruction`, `cleanupInstruction`, `otherInstructions`, `computeBudgetInstructions` (CU **price** only, no limit), optional `tipInstruction` if `tipAmount` set, ALTs, `blockhashWithMetadata`.

Assemble v0 tx with ALTs. Simulate at 1_400_000 CU, set limit to 1.2× consumed (cap 1.4M), then prepend CU price from the response. Cap a spiked CU price before signing. Sign with [ows-agent-wallet](sand-workflow:ows-agent-wallet). Operator confirms.

Land via own RPC **or** Jupiter send-only `https://tx.jup.ag` (`sendTransaction`, min **0.001 SOL** tip). Do not use `/execute`.

`mode=fast` (BETA) is lower latency, worse routes, global (not hot-account) priority fees — only for well-known pairs / bots. `slippageBps` default 50 or `rtse`. `maxAccounts` 1–64.

Default path for a normal swap is [jupiter-swap](sand-workflow:jupiter-swap) (`/order` + `/execute`), not this.
