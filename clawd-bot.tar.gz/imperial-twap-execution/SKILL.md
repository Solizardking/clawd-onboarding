---
name: imperial-twap-execution
description: >-
  use this for Imperial TWAP: slice planning, venue pinning, profile budget,
  durable runner
---
Imperial has order primitives, not a first-class TWAP runner. Plan slice count, interval, side, notional, venue, profile budget. Pin Phoenix or allow route. Persist state in a durable worker. Do not run TWAP off a Telegram webhook.
