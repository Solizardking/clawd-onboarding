---
name: vulcan-onboarding
description: >-
  use this for first-run Vulcan setup: paper trading, wallet, registration,
  collateral, MCP, live readiness
---
First-run Vulcan: health check, paper trading, then wallet/registration/collateral/MCP only if they want live. Start with `vulcan agent health -o json`. Never print keys. Sign live with OWS on their device when not using the Vulcan CLI signer.
