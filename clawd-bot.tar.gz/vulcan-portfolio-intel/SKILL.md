---
name: vulcan-portfolio-intel
description: >-
  use this for Phoenix portfolio snapshots: margin, positions, orders, funding,
  PnL
---
Account snapshots: `vulcan portfolio -o json`, `position list`, `trade orders`, history. Show margin, positions, resting orders, funding, PnL.
