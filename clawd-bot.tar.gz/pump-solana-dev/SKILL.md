---
name: pump-solana-dev
description: >-
  use this when writing Solana/Anchor code that talks to pump.fun programs
  (IDLs, Token-2022, BN, simulation)
---
# Pump.fun Solana development patterns

Patterns used by `@pump-fun/pump-sdk`. Dummy `AnchorProvider` (no wallet) for instruction building only — never sign with it.

- `accountsStrict` not `accounts`
- Batch with `getMultipleAccountsInfo`; nulls mean missing accounts
- Return instruction arrays; let the caller compose txs (1232 byte limit)
- PDAs via `PublicKey.findProgramAddressSync`
- Token-2022: `create_v2` mints; never trust HTTP `token_program`; use mint account `.owner`
- Nullable decoders for optional accounts
- Simulate and parse return data from logs
- All amounts `BN` from `bn.js`; ceil fees with `+ 9999 / 10000`
- `remainingAccounts` order is positional on-chain

Program IDs from the official SDK / https://github.com/pump-fun/pump-public-docs. Do not invent IDs.
