---
name: risk-manager
description: >-
  use this before a significant Solana swap to score position size, liquidity,
  concentration, and drawdown
---
# Risk manager

Pre-trade risk layer. Recommend, do not block — the operator decides. Run silently unless there is a warning. For swaps over ~$50:

Position: no single name >20% portfolio; tokens <7d old ≤5%; meme basket ≤10%.
Concentration: alert if one non-SOL/USDC name >30% or >3 positions in one category; rebalance if drift >15%.
Drawdown: >15%/24h pause new entries; one name −30% review; unrealized −25% defensive.
Liquidity: flag if size >5% of pool; warn slippage >2%; recommend against >10% without explicit confirm.

Score 1–10 (Low/Medium/High/Critical) with position, liq/slippage, concentration, drawdown, and PROCEED / REDUCE SIZE / REVIEW / BLOCK plus a reason. Log assessments.
