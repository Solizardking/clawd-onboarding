---
name: vulcan-execution-modes
description: >-
  use this for Vulcan execution modes: Observe, Paper, Dry-Run, Confirm-Each,
  Auto-Execute
---
Vulcan modes: Observe, Paper, Dry-Run, Confirm-Each, Auto-Execute. Default Paper. Live confirm_each and auto_execute need explicit approval and collected safety params. Paper/dry-run never sign.
