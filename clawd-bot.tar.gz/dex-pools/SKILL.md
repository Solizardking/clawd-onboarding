---
name: dex-pools
description: >-
  use this when checking Solana DEX liquidity, OHLCV, or the deepest venue for a
  token via GeckoTerminal
---
# DEX pools (GeckoTerminal)

Read-only Solana liquidity, venues, and OHLCV. No API key. ~30 req/min; on 429 wait and retry.

Use before a swap to see if slippage is real (thin pool) and which venue is deepest.

Public GeckoTerminal API: token price/FDV/mcap + pools by liquidity; one pool's volume/buys/sells/age; OHLCV (`day`/`hour`/`minute`); search; trending Solana pools.

Lead with the punchline (deepest venue, liq vs trade size). New tokens may not be indexed — fall back to RPC / rug-check. Prices are indexer estimates; executable price comes from the quote path (Pump SDK, Jupiter, DFlow), not this skill.
