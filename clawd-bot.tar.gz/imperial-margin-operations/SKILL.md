---
name: imperial-margin-operations
description: >-
  use this for Imperial profile funding, deposit/withdraw tx building, and
  margin-state reporting
---
`POST /api/v1/deposit/build-tx`, `GET /api/v1/mobile/balances`. Profile-scoped. `build-tx` is partially signed — wallet still signs (OWS). Native SOL is not direct collateral. Confirm every deposit/withdraw.
