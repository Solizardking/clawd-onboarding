---
name: pumpfun-trading
description: >-
  use this when buying or selling a pump.fun token on the bonding curve or
  graduated PumpSwap AMM
---
# Pump.fun trading

Buy and sell on the bonding curve or graduated PumpSwap with `@pump-fun/pump-sdk@1.36.0`. Prefer v2 for **every** coin, including old SOL coins. Never auto-send. Operator signs.

Docs: https://github.com/pump-fun/pump-public-docs (`docs/instructions/BUY.md`, `SELL.md`, `docs/FEE_RECIPIENTS.md`)

## State

`OnlinePumpSdk.fetchBondingCurveSummary(mint)`. Graduated when `complete` and `real_token_reserves == 0`. Detect quote from `BondingCurve.quote_mint` (default pubkey means SOL; still pass `quoteMint = NATIVE_MINT`). Base token program = mint owner (Token-2022 vs SPL). Quote token program is independent and **must** be legacy SPL. Never trust HTTP `token_program`. Field rename: `real_sol_reserves` / `virtual_sol_reserves` are now `real_quote_reserves` / `virtual_quote_reserves`.

## Curve — always v2

`buy_v2` / `sell_v2` / `buy_exact_quote_in_v2`. No optional accounts. Same order for every coin type.

- buy_v2 and buy_exact_quote_in_v2 = **27** accounts. sell_v2 = **26** (no `global_volume_accumulator`).
- Mandatory even if empty: `sharing_config` (fees PDA `["sharing-config", base_mint]`; may be empty — do not deserialize blindly), `user_volume_accumulator` (Pump PDA `["user_volume_accumulator", user]`, writable, init-if-needed), `fee_config` + fee program `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ`.
- First UVA init: 0.0018444 SOL (137-byte rent). SOL-paired associated quote ATAs need not exist.
- If bonding-curve data length is under 115 bytes, v2 top-ups rent. Older docs still say prepend `extend_account` if under 150.
- Pass **both** `feeRecipient` and `buybackFeeRecipient`. Mayhem coins use the reserved 8 as feeRecipient. Everyone uses the buyback 8 as buybackFeeRecipient. Randomize within the correct set. See [pump-program-ids](sand-workflow:pump-program-ids).
- `buy_exact_quote_in_v2(spendable_quote_in, min_tokens_out)` is the quote-budget path (fees taken from the spendable budget). Prefer it when they specify a quote budget, not a token amount.

Quote with BN, never JS number. Recheck curve immediately before sign. Prefer ~400k CU for v2 (FAQ 100k is a lower bound and often too low).

Legacy buy/sell still work for SOL-only coins and cannot trade USDC coins.

## AMM (graduated)

Program `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`. Quote **effective** quote reserves: `pool_quote_token_account.amount + Pool.virtual_quote_reserves` (i128; 0 on all pools today; BuyEvent/SellEvent append the field). Base side is still raw vault amount.

- `ammBuyInstruction` — `baseAmountOut` + `maxQuoteAmountIn`
- `ammBuyExactQuoteInInstruction` — `quoteAmountIn` + `minBaseAmountOut`
- `ammSellInstruction` — `baseAmountIn` + `minQuoteAmountOut`

Legacy AMM cashback remaining accounts (v2 curve trades do this automatically): buy `[amm_uva_wsol_ata]`; sell `[amm_uva_wsol_ata, amm_uva]`. Pump vs AMM UVAs use the **same seeds, different program IDs**.

LP: [pump-migrate](sand-workflow:pump-migrate). Cashback claim: [pump-cashback](sand-workflow:pump-cashback).

## Send

Default RPC `sendRawTransaction`. Front-runner protection → Jito only. `encoding: "base64"` when the builder used base64. Confirm size, slippage, and mint. No sniping off the live pumpfun stream without an explicit go-ahead. Fees: do not hardcode bps; read FeeConfig (canonical pools use market-cap tiers; non-canonical AMM uses flatFees; non-SOL uses `stable_fee_tiers`).
