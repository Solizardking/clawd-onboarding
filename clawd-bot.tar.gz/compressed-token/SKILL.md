---
name: compressed-token
description: >-
  use this for Light Protocol compressed token mint/transfer/compress/decompress
  on Solana
---
# Compressed tokens (Light)

~400x cheaper than SPL. `@lightprotocol/compressed-token` + `createRpc()` from `@lightprotocol/stateless.js`. Create mint, mint, transfer, approve, revoke, compress, decompress, merge, Token-2022 with compression. Accounts are rent-free. Not a pump.fun bonding curve.
