---
name: qedgen
description: >-
  use this when formally verifying code with Lean 4 / QEDGen (proofs,
  invariants, Solana program specs, qedgen, Leanstral)
---
# QEDGen — Lean 4 formal verification

Formally verify programs by writing Lean 4 models and proofs. Use when the operator wants qedgen, Lean proofs, invariants, or mathematical guarantees about an implementation (including Solana programs).

You are the proof engineer. Read the code, write models and theorems, iterate on `lake build` errors. Call Leanstral only for `sorry` goals you cannot fill after 2–3 attempts (`qedgen fill-sorry --file … --validate`). Needs `MISTRAL_API_KEY` via secret-request, never paste.

## Scope

1. If `spec.md` exists, use it. If an IDL exists, `qedgen spec --idl <path>` then refine. Else read source and ask **one** scoping question at a time (security goals, worst scenario, unenforced assumptions).
2. Write `formal_verification/SPEC.md` with MUST/MUST NOT/MAY: security goals, state model, operations (signers, pre/post), formal properties, trust boundary, results table. Confirm the spec before proving.
3. `qedgen setup` (first Mathlib cache 15–45 min). Toolchain `leanprover/lean4:v4.15.0`. Layout: `lakefile.lean`, `lean_support/`, `Proofs.lean`, `Proofs/*.lean`.

## Modeling

`import QEDGen.Solana` / `open QEDGen.Solana`. Types: `Pubkey`, `U64`, `Account`, `Lifecycle`, CPI structs. Transitions as `Option State` (`none` on precondition fail). Patterns: access control (signer = authority), CPI correctness (`rfl`), lifecycle (`closes`), conservation (`omega` after unfolding the predicate in **both** hypothesis and goal), arithmetic bounds.

Do: `unfold f at h` before `split_ifs`; `unfold pred at h_inv ⊢`; `cases h`; `omega` for linear arithmetic; `exact ⟨rfl, …⟩`. Don't: `simp [f]` before `split_ifs`; unfold only in the goal.

Report: **Verified** (compiles, no sorry), **Partial** (sorry left), **Open**. First `lake build` is slow; `could not resolve HEAD` → drop `.lake/packages/mathlib` and `lake update`.
