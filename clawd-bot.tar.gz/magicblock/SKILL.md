---
name: magicblock
description: >-
  use this for MagicBlock ephemeral rollups: delegation, cranks, VRF, private
  payments, sponsorship
---
# MagicBlock ephemeral rollups

Delegation/undelegation, dual connection (base + ER), cranks, VRF, magic actions (ER-commit + base follow-up), private payments API, commit sponsorship, lamports top-up, TS/Anchor. Use for high-throughput Solana apps. Do not mix ER keys into OWS pump wallets.
