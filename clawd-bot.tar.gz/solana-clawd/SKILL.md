---
name: solana-clawd
description: >-
  use this when setting up or operating the solana-clawd engine (MCP tools,
  Telegram bot, OODA loop, Metaplex helpers, vault, Vulcan perps)
---
# solana-clawd agentic engine

Operate [solana-clawd](https://github.com/x402agent/solana-clawd) (npm `solana-clawd`, live [solanaclawd.com](https://solanaclawd.com)). `$CLAWD` mint `8cHzQHUS2s2h8TzCmfqPKYiM4dSt4roa3n7MyRLApump`. Use when setting up that engine, its MCP tools, Telegram bot, Metaplex mint helpers, vault, OODA loop, or Phoenix perps (Vulcan).

Do **not** clone the repo onto this agent's computer unless the operator explicitly asks. Do not paste `SOLANA_PRIVATE_KEY`, vault passphrases, or Telegram tokens into chat. Prefer Helius via the Helius connector/plugin already in this bot, and Metaplex via [mint-agent](sand-workflow:mint-agent).

One-shot on **their** machine: `git clone https://github.com/x402agent/solana-clawd && cd solana-clawd && npm run setup`. Minimum live key: `HELIUS_API_KEY`. Demo with no keys: `npm run demo`. Skill pack: `npx skills add x402agent/solana-clawd`.

MCP (31 tools): market data (`solana_price`, trending, token info, wallet PnL…), Helius (account, DAS, webhooks), agent fleet, memory, Metaplex (`metaplex_mint_agent`, register, read, delegate, verify, wallet), Pump (`pump_token_scan`, quotes, graduation, cashback), skills browse. Public HTTP: `https://solana-clawd.fly.dev/mcp`. Local: `node MCP/dist/index.js` with `HELIUS_API_KEY`.

Pump tape this bot already uses: `wss://clawd-ws.fly.dev/ws` ([pump](sand-workflow:pump)). Phoenix perps: paper default; live needs explicit `--yes`. Never print private keys. Voice (ElevenLabs / Grok) and Telegram (`TELEGRAM_BOT_TOKEN`, lock `TELEGRAM_ALLOWED_CHATS`) stay on their host.

Metaplex templates in that repo (`explorer`, `scanner`, `trader`…) still need a public metadata `uri` and unsigned signing — use [mint-agent](sand-workflow:mint-agent) here. Vault in that repo is AES-256-GCM; our local equivalent is [local-encrypted-wallet](sand-workflow:local-encrypted-wallet) / OWS.

Node 20+. No dotenv auto-load for the Telegram bot (`source .env` first). Helius free tier is 1M credits/month — do not high-frequency poll.
