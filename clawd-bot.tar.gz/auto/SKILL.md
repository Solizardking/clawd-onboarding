---
name: auto
description: >-
  use this when the user runs /auto or wants to pick a token or token type,
  generate a wallet, and have Clawd automate trades
---
# /auto — pick a token (or type), mint a wallet, let Clawd trade

Use when the operator runs `/auto`, says “automate this coin”, or wants Clawd Automaton to trade a mint or a **class** of tokens. Source: [clawd-automation](https://github.com/solizardking/clawd-automation) (`@onchainai/automation`). Do **not** clone that repo. Do not print or load `SOLANA_PRIVATE_KEY`, `~/.automaton/wallet.json`, or mnemonics.

This bot **is** the loop. Optional: they can also run the npm runtime on their machine (`automaton --setup` then `--run`) via [clawd-automation](sand-workflow:clawd-automation). Default spend path: operator confirms. Autonomous signing only with an OWS policy (program allowlist + spend cap).

Paper first. Never snipe. Beach (stop) before harm.

## 1. Pick the target

Ask once, clearly:

- **One mint** — base58 mint, ticker, or a launch from `/pump`.
- **A type** — one of:
  - `new-pump` — live pumpfun stream (`wss://clawd-ws.fly.dev/ws`), still on the curve
  - `graduated-pump` — completed curves / PumpSwap
  - `sol-stable` — SOL, USDC, USDT, LSTs
  - `high-volume-meme` — DexScreener Solana, min **$100k** 24h volume and **$50k** liquidity (constitution `strategy.md` baseline)
  - custom filters they name (age, mcap, holders)

Resolve type → candidate mints with [pump](sand-workflow:pump), [dex-screener-scanner](sand-workflow:dex-screener-scanner), [alpha-scanner](sand-workflow:alpha-scanner). Rug-check every mint before it is tradable ([rug-check](sand-workflow:rug-check), [risk-manager](sand-workflow:risk-manager)). Show the shortlist; they pick.

If they already named a mint, skip the type menu.

## 2. Generate a dedicated wallet

Do **not** reuse the operator’s main treasury. One OWS wallet per auto job, on **their** device:

```bash
ows create --name auto-<ticker-or-type> --chain solana
ows address auto-<ticker-or-type>
```

Follow [ows-agent-wallet](sand-workflow:ows-agent-wallet). Never export the mnemonic. Show only the pubkey. Ask them to fund it (SOL for gas + the input token). Privy agent-signer is the server-side option ([privy-agentic-wallets](sand-workflow:privy-agentic-wallets)); do not put `appSecret` in chat.

If they insist on the Automaton wizard: `automaton --init` writes `~/.automaton/wallet.json` mode `0600` on **their** machine. Treat that as a local-dev fallback, not the public path.

## 3. Size and gates (constitution baseline)

From clawd-automation `constitution/strategy.md` unless they override:

- position ≤ **10%** of that wallet
- stop **−8%**, take **+20%**
- max slippage **2%** (200 bps) unless RTSE on Jupiter
- min 24h volume **$100k**, min liquidity **$50k** (skip these two on explicit `new-pump` sniping they asked for, but still rug-check)
- RSI 70/30, EMA 20/50 as optional overlays — never the only reason to buy

Also: max daily loss, max open positions (default 1 on a single-mint job, 3 on a type job). Quote, then size, then confirm.

## 4. Trade path

- Still on the pump.fun **bonding curve** → [pumpfun-trading](sand-workflow:pumpfun-trading) (`buy_v2` / `sell_v2` / `buy_exact_quote_in_v2`).
- Graduated / any other mint with DEX liquidity → [jupiter-swap](sand-workflow:jupiter-swap) `GET /order` + `POST /execute`. Partial-sign with OWS (JupiterZ co-signs).
- Custom CPI / Jito → [jupiter-build](sand-workflow:jupiter-build), not `/execute`.

Confirm venue + size once. Sign on device. Log signature + Solscan link.

## 5. Keep it running

After the first confirmed paper or live tick, create a Grok Bot **routine** (do not poll in chat):

- **Paper:** weekday daytime in their zone, coarsest useful cadence (e.g. every 30 min 9–17 weekdays).
- **Live:** they must say they want it live. Then the loop is time-critical — run through market hours they name, or 24/7 if they said “around the clock”. Name that reason when you save the routine.
- Prompt the routine: observe (price, curve vs AMM, rug flags, wallet balances) → apply gates → if still valid, quote → size → if paper, journal only; if live **and** a policy/spend cap exists, sign; else ping the operator. Beach on stop-loss, daily-loss cap, Law I, empty wallet, or they said stop.
- Delete the routine when the job ends (they stop, TP/SL hit and they don’t reopen, or deadline).

Paper dashboard in the upstream repo is `ooda` on `127.0.0.1:4173` (`/trade.html` is Phantom in-browser; this bot does not hold that key). Prefer this bot’s routine + OWS.

## Beach (stop)

Stop immediately if: rug flags flip, liquidity/volume collapse, stop-loss hits, OWS/policy refuses, credits/RPC die, or Law I (harm). Say you beached and why. No revenge trades.
