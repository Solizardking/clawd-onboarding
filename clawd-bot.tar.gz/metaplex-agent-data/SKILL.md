---
name: metaplex-agent-data
description: >-
  use this when reading a Metaplex agent identity, Asset Signer PDA, or DAS
  is_agent / agent_token fields
---
# Read Metaplex agent data

Read and verify a registered agent on-chain or via DAS. Docs: https://www.metaplex.com/docs/agents/read-agent-data

Program IDs: Agent Registry `1DREGFgysWYxLnRnKQnwrxnJQeSMk2HmGaC6whw2B2p`, MPL Core `CoREENxT6tW1HoK8ypY1SxRMZTcVPm7R94rH4PZNhX7d`. Asset Signer seeds `["mpl-core-execute", <core_asset>]`.

## SDK

- Exists?: `safeFetchAgentIdentityV1(umi, findAgentIdentityV1Pda({ asset }))` — null if unregistered
- Throws if missing: `fetchAgentIdentityV1FromSeeds`
- Plugin: `fetchAsset` → `agentIdentities[0]` (uri + Transfer/Update/Execute hooks)
- Off-chain profile: `fetch(agentIdentity.uri)` (ERC-8004 JSON)
- Wallet: `findAssetSignerPda({ asset })` — no private key; anyone can send funds; only Core Execute can spend

`findAssetSignerPda` and DAS `asset_signer` are the same PDA.

## DAS (indexed)

Need a DAS RPC + `@metaplex-foundation/digital-asset-standard-api`. Fields on `MplCoreAsset` only: `is_agent`, `asset_signer`, optional `agent_token` (after `setAgentTokenV1`, permanent).

- One agent: `getAsset(coreAsset)`
- Discover: `searchAssets({ isAgent: true, interface: "MplCoreAsset", limit: 100 })`
- By token: `searchAssets({ agentToken: mint })`
- By wallet: `searchAssets({ assetSigner: pda })`

JSON-RPC uses snake_case; search params camelCase (`isAgent`, `agentToken`, `assetSigner`). Registered agents without a linked token omit `agent_token`. Non-Core assets omit all three fields. Provider support varies.

Read-only. Never treat DAS as a signing path.
