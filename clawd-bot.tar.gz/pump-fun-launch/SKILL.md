---
name: pump-fun-launch
description: >-
  use this when creating a pump.fun coin, create-and-buy, or trading the bonding
  curve / PumpSwap
---
# Pump.fun launch and trade

Use the official SDK and public docs. Cheshire Terminal pump tools are fine when connected; otherwise build with `@pump-fun/pump-sdk@1.36.0` (pulls `@pump-fun/pump-swap-sdk`). Do not use community `@nirholas/pump-sdk`. Builders return instructions. They do not sign or broadcast. Never submit a transaction unless the operator confirmed mint, amounts, and wallet.

Canonical docs: https://github.com/pump-fun/pump-public-docs
IDLs in that repo: `idl/pump.json`, `idl/pump_amm.json`, `idl/pump_fees.json`
Instruction docs: `docs/instructions/{COIN_CREATION,BUY,SELL,COLLECT_CREATOR_FEE,CREATOR_FEE_SHARING}.md`, `docs/FEE_RECIPIENTS.md`, `docs/PUMP_PROGRAM_README.md`
Rust: `pump-rust-client`

## Program IDs (mainnet = devnet)

- Pump: `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`
- PumpSwap AMM: `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`
- Pump Fees: `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ`
- Mayhem: `MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`
- Global PDA: `4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf` (seed `["global"]`)
- Token-2022: `TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb`
- wSOL: `So11111111111111111111111111111111111111112`

PDA seeds (get these right):

- Bonding curve: `["bonding-curve", mint]` (Pump)
- Pump creator vault: `["creator-vault", bonding_curve.creator]` (hyphen)
- AMM creator vault: `["creator_vault", coin_creator]` (underscore)
- Sharing config: `["sharing-config", mint]` (Pump Fees)
- Fee config: `["fee_config", pump_program_id]` (Pump Fees)
- User volume accumulator: `["user_volume_accumulator", user]` (Pump)

## Operator fill-ins (never invent)

- RPC (mainnet vs devnet; npm samples use devnet)
- Wallet that signs as `user`, plus a **mint Keypair** on create (not `PublicKey.unique()` — those sample txs fail)
- Metadata: name ≤ 32, symbol ≤ 13, uri ≤ 200 (hosted JSON)
- Optional: mayhem mode, cashback, non-SOL quote mint
- Creator pubkey if different from signer (creator does **not** sign; it still receives fees unless sharing is set)
- Buy size + slippage
- For existing coins: mint address; fetch curve/pool/share state rather than assuming

## Create — prefer `create_v2`

`create_v2` is Token-2022 with metadata on the mint. Legacy `create` is Metaplex + SPL Token and is being deprecated. Mixing token programs is a common fail.

Signers: **mint Keypair** and **user** (payer). Creator does not sign. Creator can differ from user (free-create: first buyer pays, original creator still gets fees).

High-level:

```
sdk.createInstruction({ mint, name, symbol, uri, creator, user })
sdk.createAndBuyInstructions({ global, mint, name, symbol, uri, creator, user, solAmount, amount })
```

Current docs (`PUMP_SDK` singleton):

```
PUMP_SDK.createV2Instruction({ mint, name, symbol, uri, creator, user, mayhemMode, cashback, quoteMint? })
```

`createAndBuy` is one tx. Quote the first buy with `getBuyTokenAmountFromSolAmount(global, null, solAmount)` (null curve = initial curve).

Non-SOL quote remaining accounts: `quote_mint`, `associated_quote_bonding_curve`, `quote_token_program` — all three or none.

When Cheshire is connected, prefer its pump launch / confirm-launch / submit tools, then still show the unsigned payload before send.

Graduation: when `real_token_reserves == 0` / `complete == true`, permissionless `migrate` / `migrate_v2` seeds a canonical PumpSwap pool and burns LP. After that, trade on PumpSwap, not the curve.

## Buy / sell — prefer v2

Prefer `buy_v2`, `sell_v2`, `buy_exact_quote_in_v2`. Legacy buy/sell still work for SOL-only. Signer is `user` only.

Flow: `fetchGlobal()` → `fetchBuyState` / `fetchSellState` → quote → `buyInstructions` / `sellInstructions` with slippage.

v2 extras agents miss:

- `sharing_config` PDA is mandatory even if uninitialized
- `user_volume_accumulator` is mandatory (first buy pays ~0.0018444 SOL rent)
- Both `feeRecipient` and `buybackFeeRecipient` required
- Mayhem coins use reserved fee recipients; others use the normal 8 (see `FEE_RECIPIENTS.md`)
- `create_v2` coins: pass `TOKEN_2022_PROGRAM_ID` as the base token program
- SOL-paired: still pass `quoteMint = NATIVE_MINT`; native SOL moves; quote ATAs are seed-constrained and need not exist
- Compute: ~100k CU for trades; fee-share distribute uses ~400k

Quote PumpSwap with **effective** quote reserves: `pool_quote_token_account.amount + Pool.virtual_quote_reserves`. Use that even when `virtual_quote_reserves` is 0 today.

## Safety

- Quote before build. Recheck curve state immediately before the operator signs.
- No optional-account guessing on v2.
- Do not invent program IDs. Read them from the SDK or the public docs.
- Spending SOL, creating a mint, or sending a tx is a go/no-go. Confirm once, then build.

## Sign with OWS

After the operator confirms mint, amounts, and wallet, sign the VersionedTransaction on Solana via OWS (`ows sign tx --wallet <name> --chain solana --tx <raw>`). Never print keys. Prefer the Solana address from an OWS vault wallet as `user`. Operator confirms each spend unless an explicit OWS policy and spend cap are set.
