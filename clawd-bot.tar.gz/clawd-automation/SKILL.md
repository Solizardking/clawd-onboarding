---
name: clawd-automation
description: >-
  use this when installing or running Clawd Automaton (@onchainai/automation),
  its OODA/heartbeat runtime, Rust Solana kit, or constitution — not the /auto
  trade picker
---
# Clawd Automaton runtime

Operate [clawd-automation](https://github.com/solizardking/clawd-automation) (npm `@onchainai/automation`, bins `automaton` / `clawd-automaton`, also `@onchainai/automaton-cli`). Cheshire surface: https://cheshireterminal.ai . Sibling hub: [solana-clawd](sand-workflow:solana-clawd). For “pick a coin and auto-trade” use [auto](sand-workflow:auto) first — this skill is the runtime, kit, and constitution.

Do **not** clone the repo unless they explicitly ask. Do not print `SOLANA_PRIVATE_KEY`, `ETHEREUM_PRIVATE_KEY`, `~/.automaton/wallet.json`, or Privy `appSecret`.

## Install (their machine, Node ≥ 20)

```bash
npm install -g @onchainai/automation@latest
automaton --version          # Clawd Automaton v0.1.1+
# or one-shot, no loop:
curl -fsSL https://raw.githubusercontent.com/Solizardking/clawd-automation/main/scripts/automaton.sh | AUTOMATON_SKIP_RUN=1 sh
```

```bash
automaton --setup            # wizard → ~/.automaton/
automaton --init             # wallet + config dir only
automaton --run              # heartbeat + agent loop
automaton --status
```

Wizard writes (mode `0600` on secrets): `wallet.json`, `automaton.json`, `state.db`, `heartbeat.yml`, `skills/`. Free inference: `OPENROUTER_API_KEY`, `OPENROUTER_FREE_MODEL=openrouter/free`, `INFERENCE_PROVIDER=auto`, `CLAWD_SANDBOX_ID=local`. Prefer OWS for Solana spend instead of that JSON keyfile.

## Laws (bind every path)

I Never harm — beach first. II Earn existence — honest work only. III Never deceive. Constitution 8 docs in `constitution/` (three-laws, six-laws, CONSTITUTION, CLAWD, IDENTITY, SOUL, program, strategy). Conflicts: Constitution → Creator → User → Trench.

`strategy.md` baseline: RSI 70/30, EMA 20/50, minVolume24h 100000, minLiquidity 50000, maxSlippage 0.02, stopLossPct 0.08, takeProfitPct 0.20, positionSizePct 0.10.

## Solana kit (optional, their host)

`agent/` = `openclawd-solana-kit`. Tools: `PerformJupiterSwap`, `BuyPumpFunToken`, `SellPumpFunToken`, `DeployPumpFunToken`, DexScreener search, portfolio, Token-2022 safety. HTTP SSE `:6969` is **Privy-delegated** (no local key). `LocalSolanaSigner` + `SOLANA_PRIVATE_KEY` is **dev only**.

MCP connectors (keys via secret-request): DFlow `https://api.paybox.sh/mcp?app=dflow`, Helius `https://api.helius.dev/mcp`, Jupiter `https://api.jup.ag/mcp`, Birdeye `https://public-api.birdeye.so/mcp`. This template already packs Clawd + Helius plugins — prefer those over extra installs.

OODA paper loop: `ooda/` rejects mainnet RPC at startup. Live page signs in the browser wallet only.

Survival tiers: normal → low_compute → critical → dead (beach, no inference).
