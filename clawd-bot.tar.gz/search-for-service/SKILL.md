---
name: search-for-service
description: >-
  use this to find live x402 services on x402scan or the Coinbase bazaar, Solana
  by default
---
Find paid x402 APIs. No API key.

Public explorer: `https://x402scan.achivx.com`.

```text
GET /v1/resources/search?q=QUERY&live=true&limit=6&chain=-1
GET /v1/resources/{id}
```

`chain=-1` is Solana. `8453` is Base. Pass `chain` every time. `live=true` means the last probe passed, not that it was probed just now. Read the resource `accepts`, `last_seen`, and `risk_flags` before paying. Pay only a Solana accept.

Coinbase bazaar (also no auth), when they ask for that catalog instead:

```bash
npx awal@latest x402 bazaar search <query> [-k n] [--json]
npx awal@latest x402 details <url> [--json]
```

Then [pay-for-service](sand-workflow:pay-for-service). Selling is [monetize-service](sand-workflow:monetize-service).
