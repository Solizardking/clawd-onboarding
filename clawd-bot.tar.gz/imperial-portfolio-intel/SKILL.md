---
name: imperial-portfolio-intel
description: 'use this for Imperial profile balances, positions, orders, and operator recaps'
---
`GET /api/v1/mobile/balances`, `/positions?walletAddress=`, `/orders?walletAddress=`. Report per-profile USDC, open notional by symbol/venue, open orders, and which `profileIndex`/wallet.
