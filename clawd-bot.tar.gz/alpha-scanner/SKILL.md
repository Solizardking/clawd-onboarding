---
name: alpha-scanner
description: >-
  use this when scanning pump.fun or Solana for early launch, volume, or
  smart-money alpha reports
---
# Alpha scanner

Scan for early Solana setups and report them. Never a buy recommendation.

Look at: pump.fun / Raydium launches in the last 1–6 hours (min ~$5k liq, ~50 holders, organic holder growth); volume >5x 7d average in the $100k–$10M mcap band (skip wash-trade loops); social catalysts; several profitable wallets accumulating the same mint.

Skip: mint authority still enabled, top wallet >50% supply, liq <$5k, obvious copies, more than 5 alerts/hour.

Format: ALPHA ALERT with time, signal, mcap, liq, volume, holders, why, risk factors, confidence Low/Medium/High. Always include risks. Use the solgpt tape (`wss://clawd-ws.fly.dev/ws`) as the launch firehose, then rug-check before surfacing.
