---
name: pump-solana-wallet
description: >-
  use this when generating or validating a DIY Ed25519 Solana keypair for
  Pump.fun on the operator's device (prefer OWS first)
---
# Solana wallet generation for Pump.fun

Generate and validate Ed25519 Solana keypairs **on the operator's device only**. Prefer [ows-agent-wallet](sand-workflow:ows-agent-wallet) (`ows wallet create`) so keys never appear in chat. Use this skill only when they explicitly want a DIY keypair.

Never print, log, or paste mnemonics or secret keys. Never generate keys on this agent's computer for production funds. Offline during generation. No network.

## Approved libraries

- Rust: `solana-sdk` (`Keypair::new()`, `Signer`, Base58)
- TypeScript: `@solana/web3.js` (`Keypair.generate()`, `fromSecretKey`)
- Shell (their machine): `solana-keygen new` / `grind` / `verify`

Address: 32-byte Ed25519 pubkey, Base58, typically 43–44 chars, alphabet without `0 O I l`. Base58 ≠ Base64.

## Security

CSPRNG only (`OsRng`, `crypto.getRandomValues`). Official libs only. Zeroize when done (`Zeroize`/`Drop` in Rust; `secretKey.fill(0)` in TS is best-effort because GC can relocate). Key files `0o600`. After write, re-derive the pubkey from the secret and compare. `solana-keygen` JSON is `[u8; 64]` (32 secret + 32 public). Vanity grind is case-sensitive raw Base58; 4-char prefixes already take minutes.

For agent signing, migrate the new key into OWS (`ows wallet import`) or keep it in [local-encrypted-wallet](sand-workflow:local-encrypted-wallet). Default spend path is still operator confirms.
