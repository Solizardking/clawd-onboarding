---
name: jupiter-swap
description: >-
  use this when swapping Solana tokens via Jupiter Swap API V2 GET /order + POST
  /execute (Meta-Aggregator)
---
# Jupiter Swap V2 — order and execute

Default way to swap any Solana token (including graduated pump coins that have DEX liquidity). Meta-Aggregator: all routers compete (Metis, JupiterZ RFQ, Dflow, OKX). Jupiter lands the tx. Docs: https://dev.jup.ag/docs/llms.txt and https://developers.jup.ag/docs/swap/order-and-execute.md

Base: `https://api.jup.ag/swap/v2`. Header `x-api-key`. Keyless works at 0.5 RPS (no header). Production key from https://developers.jup.ag/portal — request `JUPITER_API_KEY` via secret-request, never paste. Keys look like `jup_…`.

Never load `BS58_PRIVATE_KEY` or a CLI keyfile here. Sign with [ows-agent-wallet](sand-workflow:ows-agent-wallet). Operator confirms every spend. Show the quote before execute.

Pump bonding-curve coins that have **not** graduated still use [pumpfun-trading](sand-workflow:pumpfun-trading), not Jupiter.

## Quote only

`GET /order` without `taker` returns a price, no transaction. Useful for checks.

## Swap (ultra)

1. Ask: input mint, output mint, amount in **smallest units**, taker pubkey (OWS Solana address).
2. `GET https://api.jup.ag/swap/v2/order?inputMint=&outputMint=&amount=&taker=` with `x-api-key` if present.
3. Show `outAmount`, `router` (`metis` | `jupiterz` | `dflow` | `okx`), `mode`, `feeBps`, `feeMint`, `platformFee`. Confirm once.
4. If `transaction` is null (no taker) or `""` (quoted but cannot build): do **not** sign. Match `router` + `errorCode` (do not match `errorMessage` strings). Aggregator: 1 insufficient funds, 2 no SOL for gas, 3 below gasless min. JupiterZ: 1 balance, 2 missing ATA, 3 could not build.
5. Sign immediately (quotes go stale). Versioned v0 tx, **partial** sign — JupiterZ adds a market-maker signature on `/execute`. `ows sign tx` / `partiallySignTransaction`.
6. `POST /execute` JSON `{ signedTransaction, requestId }` (optional `lastValidBlockHeight`). Dedicated rate bucket (keyless 20 RPS).
7. `status` Success/Failed. `code` 0 = ok. `-1` expired requestId, `-2` bad signed tx, `-1000` aggregator fail to land, `-2003` RFQ quote expired, `-2004` swap rejected. Wallet amounts: `totalInputAmount` / `totalOutputAmount`. Route amounts: `inputAmountResult` / `outputAmountResult`.

Aggregator expiry: `lastValidBlockHeight`. RFQ: `expireAt` (shorter).

Keep `/order` in **ultra** (no optional params) unless they ask. Optional params (`slippageBps`, `referralAccount`, `payer`) switch `mode` to **manual** and can drop routers. `payer` ≠ `taker` disables JupiterZ and Dflow/OKX (Metis only). Prefer all routers.

## Fees (included in quote)

JUP/JLP/jupSOL and pegged pairs 0 bps; SOL-stable 2; LST-stable 5; else 10; tokens under 24h old **50**. `feeBps` is total (can include gasless recoup); `platformFee.feeBps` is Jupiter’s cut. Fee mint priority: SOL, stables, LSTs, bluechips, other.

Referral (`referralAccount` + `referralFee` 50–255 bps) needs `@jup-ag/referral-sdk` and a `referralTokenAccount` per fee mint. Jupiter takes 20% of integrator fee. Do not invent a referral account.

Gasless: if `signatureFeePayer != taker`, someone else pays gas (Jupiter `gasTzr94Pmp4Gf8vknQnqxeYxdgwFjbgdJa4msYRpnB`, an MM, or integrator `payer`). Opt out by dropping quotes where they differ.

Price check: `GET https://api.jup.ag/price/v3?ids={mints}` (up to 50). Token search: `GET https://api.jup.ag/tokens/v2/search?query=`.
