---
name: vulcan-ta-strategy
description: >-
  use this for TA-driven Phoenix strategies with Vulcan declarative rules and
  ledgers
---
Prefer Vulcan's TA strategy runner over custom loops. Collect mode, triggers, caps, TP/SL, safety policy before launch. Paper first. Indicators from [vulcan-technical-analysis](sand-workflow:vulcan-technical-analysis).
