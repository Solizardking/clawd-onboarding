---
name: vulcan-tpsl-management
description: >-
  use this for Vulcan/Phoenix take-profit and stop-loss setup, cancel, ladders,
  and verification
---
TP/SL on Vulcan/Phoenix: direction must match position side. Verify resting conditionals after set/cancel. Live changes need `--yes`. Laddered exits ok; confirm each live attach.
