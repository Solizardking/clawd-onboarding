---
name: vulcan-quickstart
description: >-
  use this for a five-minute Vulcan install, health check, first market read,
  and first paper trade
---
Five-minute Vulcan start: `vulcan agent health -o json`, `vulcan market list -o json`, `vulcan paper init --balance 10000`, then a small paper order. No live wallet until they ask. See [vulcan-onboarding](sand-workflow:vulcan-onboarding).
