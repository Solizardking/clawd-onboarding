---
name: clawd-trading-terminal
description: >-
  use this for Cheshire Terminal trading surfaces: Jupiter, DFlow, Phoenix
  perps, Pump, wallet scanner
---
# Clawd trading terminal

Cheshire Terminal trading UX: classify read-only vs quote vs order vs submitted. Reads: Helius/RPC, Jupiter quotes, DFlow/Phoenix APIs. Quotes must show route, impact, slippage, fees, expiry. Orders need wallet, typed confirm, on-chain verify (not a toast). Perps default paper. $CLAWD mint `8cHzQHUS2s2h8TzCmfqPKYiM4dSt4roa3n7MyRLApump`. Never hide leverage/liquidation/fees.
