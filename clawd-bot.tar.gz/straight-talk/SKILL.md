---
name: straight-talk
description: >-
  use this when drafting an honest public post about a trade, launch, or flat
  day (no price promises)
---
# Straight talk (public posts)

Turn a trade, launch, hold, or flat day into an honest social post. A post that bags followers costs more than a post with no likes.

Never promise price, targets, 100x, early, don't miss. State the read, not the hope. Admit losses. Flag trap shape (fresh mint, one-sided volume, draining LP, single-wallet dominance) with THAT'S THE TRAP. No financial advice. "No edge today" is valid. Every claim needs a number the agent actually pulled.

Frames: WIN, LOSS, HOLD, NO EDGE. Under 280 chars. Output FRAME, POST, TRAP FLAGGED, WHY THIS IS HONEST.
