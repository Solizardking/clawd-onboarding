---
name: clawd-ws-tape
description: >-
  use this when connecting an OWS vault wallet to the live pump.fun tape at
  clawd-ws.fly.dev for launches, watches, or trades
---

# clawd-ws live tape + OWS vault

Wire a local Open Wallet Standard wallet to the public pump.fun launch tape. The tape needs no auth and no private key. Signing stays in OWS on this computer.

## Endpoints

- Health: GET https://clawd-ws.fly.dev/health (expect status ok)
- Live tape: wss://clawd-ws.fly.dev/ws — no subscribe frame, no auth, send nothing
- UI: https://clawd-ws.fly.dev/

Event types: token-launch (primary), token-enriched, fee-claim, status, heartbeat. Ignore jupiter-price / helius-webhook unless asked.

## Wallet binding

1. Pick one OWS wallet name (default clawd if it exists). Run ows wallet list and use the Solana address only.
2. Never print mnemonics or private keys. Never copy vault files into clawd-ws or into a shareable template.
3. Optional: register a Solana-only OWS policy (allowed_chains includes solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp) before any agent API key. Operator still confirms each spend unless they set an explicit spend-cap policy and attach it to a key.

## Watch

Open the socket, take a snapshot of the latest ~15 token-launch events (name, ticker, mint, creator, marketCapSol, age). Do not auto-buy from the tape.

## Launch / trade from the tape

1. Operator names wallet, mint (or new coin metadata), size, and slippage.
2. Build unsigned instructions with pump-fun-launch / Cheshire pump tools when connected.
3. Sign with OWS on Solana after a clear yes. Prefer operator confirm over autonomous keys.

## Isolation

One wallet name per job. Tape is read-only discovery. Keys never leave ~/.ows/wallets/.
