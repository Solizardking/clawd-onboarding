---
name: pump-mcp-server
description: >-
  use this when running or building a Pump.fun MCP server (quotes, tx builders,
  fees, session wallets)
---
# Pump MCP server

Expose Pump.fun to agents over MCP stdio. Cheshire local `pump-fun` is `@pump-fun/mcp-server` (~55 tools: quotes, builders, fees, AMM, session wallet). Helius plugin ships `pump-mcp`. Prefer those over rolling a new server.

If building a wallet MCP: session keypair only, zeroize on replace/shutdown, never log secret keys, Zod-validate inputs, no network for keygen.

Resources like `solana://config` / `solana://programs`. Mutating builders return instructions — they do not broadcast unless the operator signs.

Do not proxy Robinhood/MoonPay/PayBox through pump-fun when official HTTP MCP exists.

If stdio fails to load, the dist entry is missing (`dist/index.js`); build the package, do not invent tools.
