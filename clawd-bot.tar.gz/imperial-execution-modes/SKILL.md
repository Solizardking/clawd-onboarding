---
name: imperial-execution-modes
description: >-
  use this for Imperial execution modes: observe, route-check, paper, live
  single-shot, external runner
---
Imperial modes: `observe` (read-only), `route-check` (`/funding-rates`, `/mark-prices`, `/route`), `paper/spec` (plan, no submit), `live-single-shot` (`POST /mobile/orders`), `external-runner` (durable TWAP/grid). Telegram can do observe/route-check/live-single-shot. Long TWAP/grid needs a real runner.
