---
name: metaplex-agent-token
description: >-
  use this when launching a Genesis bonding-curve token from a Metaplex agent's
  PDA and optionally binding it with setAgentTokenV1
---
# Launch a Metaplex agent token (Genesis)

Launch the **one** canonical token for a registered Metaplex agent via Genesis `createAndRegisterLaunch`, with creator fees to the Asset Signer PDA. Docs: https://www.metaplex.com/docs/agents/create-agent-token and https://www.metaplex.com/docs/agents/agent-finance

SDK: `@metaplex-foundation/genesis` 1.x (`/api`). Hosted API builds unsigned txs. Operator signs. Never load secret keys. Confirm **twice** before `setToken: true` — it is irreversible (one token per agent forever).

Need a registered agent Core asset first ([mint-agent](sand-workflow:mint-agent) or [register-agent](sand-workflow:register-agent)).

## Ask first

- Agent Core asset address
- Network (devnet: `setToken: false` unless they insist)
- Token name (1–32), symbol (1–10), **Irys image URL only** (`https://gateway.irys.xyz/…`)
- Optional description (≤250), website/twitter/telegram
- `setToken` true/false
- Optional `firstBuyAmount` in SOL (fee-free, buyer defaults to agent PDA)
- Optional override `launch.creatorFeeWallet` (else agent PDA)

## Launch

```
createAndRegisterLaunch(umi, {}, {
  wallet: umi.identity.publicKey,
  agent: { mint: agentAssetAddress, setToken: true },
  launchType: 'bondingCurve',
  token: { name, symbol, image },
  launch: {}, // protocol defaults
  network: 'solana-mainnet' | 'solana-devnet',
})
```

Umi is only for signer + send; `genesis()` plugin not required. CLI equivalent: `mplx genesis launch create --launchType bonding-curve --agentAsset <ASSET> --agentSetToken`.

Show unsigned txs, mint address, `result.launch.link`. Do not submit until they confirm. If create confirms but registerLaunch fails, token exists on-chain but not on metaplex.com — say so.

Later bind: `setAgentTokenV1` must run as the Asset Signer via Core `execute` (noop signer on the PDA). Permanent. DAS then shows `agent_token`.

Graduation: curve fills → Raydium CPMM. Claim creator fees with `claimBondingCurveCreatorFeeV2` / `claimRaydiumCreatorFeeV2` (permissionless). Image host must be Irys or the API rejects.

Errors: `isGenesisValidationError`, `isGenesisApiNetworkError`, `isGenesisApiError`.

This is **Genesis**, not pump.fun. Pump coins stay on [create-coin](sand-workflow:create-coin). Do not mix program IDs.
