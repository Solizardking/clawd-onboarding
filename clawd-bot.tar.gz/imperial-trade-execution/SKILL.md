---
name: imperial-trade-execution
description: >-
  use this for safe Imperial live orders: Phoenix-first, profile-aware,
  post-trade verify
---
`POST /api/v1/mobile/orders`. Open: `action=0`, `orderType=0`, `fundingStatus=0`, `underwriter=2` (Phoenix). Close: `action=1`, same wallet/profile. Verify `success`, `signature`, then `/positions` and `/orders`. Live needs explicit yes. Never log `IMPERIAL_API_KEY`.
