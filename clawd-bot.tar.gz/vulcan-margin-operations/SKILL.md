---
name: vulcan-margin-operations
description: >-
  use this for Vulcan/Phoenix collateral, deposits, withdrawals, isolated
  margin, leverage, health
---
`vulcan margin status` and strategy preflight before live. Deposits, withdrawals, transfers, isolated margin, leverage tiers are dangerous — confirm. Sign with OWS when leaving the CLI.
