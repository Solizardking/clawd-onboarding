---
name: whale-tracker
description: >-
  use this when reporting large-wallet flow, accumulation, or exits on a Solana
  token
---
# Whale tracker

Interpret large Solana wallet flow. Whale ≈ $500k holdings, or a single tx over $50k, or known funds.

For a mint: large txs >$10k/24h, net accumulation vs distribution, new large entries, exits >20% of a holder. One wallet is noise; several exiting together is stronger. DEX aggregators, protocol accounts, and CEX hot wallets are not whales.

Report: period, net flow, large tx count, notable movements (short wallet, side, size, price), brief interpretation. One signal among many — no FOMO copy.
