---
name: publish-cursor-marketplace-plugin
description: >-
  Use when the owner wants to publish a Cursor/Agent Plugin to
  https://cursor.com/marketplace/publish — prepare the repo, fill the form, and
  stop for explicit approve before submit.
---
# Publish to Cursor Marketplace

Irreversible from the owner's POV until review. **Fill the form. Do not click Submit Application until they approve.**

## Preconditions checklist

From https://cursor.com/docs/reference/plugins :

- Valid root `plugin.json` (Agent) or `.cursor-plugin/plugin.json` (Cursor)
- `name` unique, lowercase kebab-case
- Clear `description`; components have valid frontmatter
- `README.md` covers usage and config
- Agent Plugins match agent-plugins schemas; every `${VAR}` in mcp config is declared under `variables`
- Paths relative (no `..`, no absolutes)
- Logo committed and referenced by relative path if used
- Multi-plugin repos have `.cursor-plugin/marketplace.json`
- Proven locally via prove-plugin-local

## GitHub repo

If none exists:

1. Ask owner for org/user, public vs private (marketplace needs a **public** git repo), and repo name (default to plugin `name`).
2. Create with `gh repo create <owner>/<name> --public --source=<plugin-dir> --remote=origin` (or CloudAgent) after they confirm the name.
3. Commit only plugin files (no secrets, no `.env`, no local-only verify junk).
4. Push default branch. Record the HTTPS repo URL.

If a repo exists: confirm it is public, on the default branch, and contains the manifest at the expected path.

## Fill publish form

Open https://cursor.com/marketplace/publish (signed-in as the owner).

Live form fields (match labels on the page):

| Field | What to put |
| --- | --- |
| Organization name | Owner/org display name |
| Organization handle | Unique kebab-case namespace, e.g. `@acme-labs` |
| Contact email | Owner contact |
| Logotype URL | `https://…` to 1:1 SVG or PNG with background plate (or leave blank) |
| Description | From plugin manifest / README; what it does and who it helps |
| GitHub repository | Public repo URL containing the plugin |
| Owner | Often disabled ("Submitting as your team") — leave as-is |
| Website URL | Optional product/site URL |

Also note Publisher Terms link + consent copy: submitting means they agree to Publisher Terms.

Do **not** invent API keys or paste secrets into the form or chat.

## Approve gate

Send a question widget:

- prompt: submit this plugin application to the Cursor Marketplace now?
- options: Submit Application / Hold off

Only on explicit Submit Application: click **Submit Application**, then report success or the error text. On Hold off or dismiss: leave the form filled, do not submit.

## After submit

Tell the owner review is manual, listing is not instant, and give them the repo URL + anything the confirmation page shows.
