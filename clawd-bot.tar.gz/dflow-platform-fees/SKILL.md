---
name: dflow-platform-fees
description: >-
  use this to take a builder cut on DFlow trades via platformFeeBps or
  platformFeeScale
---
# DFlow platform fees

Builder fee on Trade API: `platformFeeBps` (spot + PM) or `platformFeeScale` (PM outcome tokens only). `platformFeeMode` `outputMint` default; imperative spot also allows `inputMint`; PM always settlement mint (USDC/CASH). `feeAccount` must already exist. CLI has no monetization flags. Not for running the trade itself.
