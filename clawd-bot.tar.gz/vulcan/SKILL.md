---
name: vulcan
description: >-
  use this when the user mentions Vulcan, Phoenix perps, Solana perps,
  paper/live perps, TWAP, grid, or TP/SL on Phoenix
---
# Vulcan — Phoenix perps

Entry skill for Phoenix perpetuals via Vulcan/Rise (`vulcan` CLI, `clawd-agents-perps`). Use before any Vulcan, Phoenix DEX, Solana perps, paper/live, margin, TP/SL, TWAP, grid, or TA work. Source family: https://github.com/Solizardking/skills (`vulcan/*`).

Paper and dry-run never need a wallet. Live needs an explicit yes plus Vulcan `--yes` or MCP `acknowledged=true`. Inspect market, margin, and positions before opening exposure. Never guess lot sizes — `vulcan-lot-size-calculator`. Never print keys. Report every fill and signature.

Route: [vulcan-quickstart](sand-workflow:vulcan-quickstart), [vulcan-trade-execution](sand-workflow:vulcan-trade-execution), [vulcan-risk-management](sand-workflow:vulcan-risk-management), [vulcan-twap-execution](sand-workflow:vulcan-twap-execution), [vulcan-grid-trading](sand-workflow:vulcan-grid-trading), [vulcan-tpsl-management](sand-workflow:vulcan-tpsl-management), [vulcan-margin-operations](sand-workflow:vulcan-margin-operations), [vulcan-market-intel](sand-workflow:vulcan-market-intel), [vulcan-portfolio-intel](sand-workflow:vulcan-portfolio-intel), [vulcan-position-management](sand-workflow:vulcan-position-management), [vulcan-execution-modes](sand-workflow:vulcan-execution-modes), [vulcan-error-recovery](sand-workflow:vulcan-error-recovery), [vulcan-ta-strategy](sand-workflow:vulcan-ta-strategy), [vulcan-technical-analysis](sand-workflow:vulcan-technical-analysis), [vulcan-onboarding](sand-workflow:vulcan-onboarding), [vulcan-lot-size-calculator](sand-workflow:vulcan-lot-size-calculator). Index: [vulcan-skills-index](sand-workflow:vulcan-skills-index).

First commands: `vulcan agent health -o json`, `vulcan market list -o json`, `vulcan paper init --balance 10000`. Imperial is the router layer ([imperial](sand-workflow:imperial)); Vulcan is Phoenix-native execution.
