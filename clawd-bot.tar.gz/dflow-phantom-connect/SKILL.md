---
name: dflow-phantom-connect
description: >-
  use this to build Phantom-connected Solana apps that trade on DFlow (spot,
  Kalshi, Proof KYC)
---
# DFlow + Phantom Connect

Wallet-connected apps with `@phantom/react-sdk`, react-native-sdk, or browser-sdk plus DFlow spot/PM/Proof. Wallet Standard auto-discovery (`wallets={[]}`). Prefer OWS on this bot for operator spends; use Phantom Connect when they are building a user-facing app. Not for EVM wallets or non-DFlow DEX routing. Do not install a Phantom Cursor plugin unless they ask.
