---
name: trending
description: use this when the user runs /trending to list hot pump.fun and Solana tokens
---
# /trending — what’s moving

Use when they run `/trending` or ask for hot Solana / pump coins. Read-only. Do not auto-buy.

1. Latest pump launches: [pump](sand-workflow:pump) (`wss://clawd-ws.fly.dev/ws`), newest 10.
2. DexScreener Solana trending/gainers: [dex-screener-scanner](sand-workflow:dex-screener-scanner). Prefer volume ≥ $100k and liquidity ≥ $50k unless they asked for new-pump.
3. Optional: Jupiter token search / Birdeye if those keys exist.

One short list: name, ticker, mint, venue (curve vs DEX), mcap/vol. Then: “`/buy <mint> <sol>` or `/auto <mint>`.”
