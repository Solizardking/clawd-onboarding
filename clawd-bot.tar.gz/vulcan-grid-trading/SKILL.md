---
name: vulcan-grid-trading
description: >-
  use this for Phoenix perps grid trading: setup, monitor, pause/stop, paper vs
  live
---
Phoenix grid: use Vulcan's grid runner, not a custom scheduler. Detached monitor for long runs. Report each fill/replacement with signatures. Live grid needs explicit yes.
