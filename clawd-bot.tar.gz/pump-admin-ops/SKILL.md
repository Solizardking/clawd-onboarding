---
name: pump-admin-ops
description: >-
  use this when the operator is pump.fun protocol admin (toggles, authority) or
  needs permissionless creator migration helpers
---
# Pump.fun admin operations

Protocol admin only. Most importers should never run these. Require proof the signer is `global.authority` before building. Spending or transferring authority is a hard confirm.

Toggles (global authority): `toggleMayhemModeInstruction`, `toggleCashbackEnabledInstruction`, `toggleCreateV2Instruction`.

`updateGlobalAuthorityInstruction` is **irreversible**. Read the new address back twice.

`setReservedFeeRecipientsInstruction` needs the whitelist PDA.

Permissionless creator helpers (anyone): `setMetaplexCreatorInstruction({ mint })`, `migrateBondingCurveCreatorInstruction({ mint })`, `ammSetCoinCreatorInstruction`, `ammMigratePoolCoinCreatorInstruction`.

`AdminSetCreatorEvent` has no public builder. Decode from logs only.

Do not call deprecated `RevokeFeeSharingAuthority` / `TransferFeeSharingAuthority`. Fee-share lock is the first `updateFeeShares`.
