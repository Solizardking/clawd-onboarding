---
name: dflow-kalshi-trading
description: >-
  use this to buy, sell, or redeem Kalshi YES/NO tokens via DFlow (not spot, not
  KYC setup)
---
# DFlow Kalshi trading

Buy/sell/redeem YES/NO outcome tokens on Kalshi markets via DFlow. CLI or Trading API. Proof KYC required for buys ([dflow-proof-kyc](sand-workflow:dflow-proof-kyc)). Jurisdiction checks. Atomic amounts. Maintenance Thu 3–5am ET. Guardrails before autonomous. Sign with OWS. Do not use for spot, scanning, or portfolio reads.
