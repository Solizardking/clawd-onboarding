---
name: wallet
description: >-
  use this when the user runs /wallet to generate, show, or fund a Solana OWS
  wallet or Coinbase awal Base wallet
---
# /wallet — generate or show a trading wallet

Use when the operator runs `/wallet`, `/wallet new`, or `/wallet status`. Two rails. Never mix them. Never print mnemonics, OTP codes, or secret keys.

## Solana (default for pump / Jupiter / DFlow)

On **their** device, Open Wallet Standard:

```bash
ows wallet create --name clawd --chain solana
ows wallet list
ows wallet info
```

Show only the pubkey. One wallet per job: `auto-<ticker>` for `/auto`. Fund with SOL (gas) + the input token. Sign spends with [ows-agent-wallet](sand-workflow:ows-agent-wallet). Operator confirms. Do not write `SOLANA_PRIVATE_KEY` or `~/.automaton/wallet.json`.

`/wallet status` lists OWS wallets and Solana addresses only.

## Base USDC (Coinbase Agentic Wallet / awal)

For onramp, Base trades, or x402 bazaar — not pump.fun. Docs: https://docs.cdp.coinbase.com/llms.txt . Install: `npx skills add coinbase/agentic-wallet-skills`.

```bash
npx awal@latest status
npx awal@latest auth login <email>     # returns flowId; OTP to email
npx awal@latest auth verify <flowId> <otp>
npx awal@latest address
npx awal@latest balance
npx awal@latest show                   # companion UI: Fund via Coinbase Onramp
```

Ask for the OTP; do not scrape their inbox unless they already connected mail. Funds land as **USDC on Base**. Send/trade on Base use [send-usdc](sand-workflow:send-usdc) / [awal-trade](sand-workflow:awal-trade). Solana pump buys still need a Solana OWS wallet.
