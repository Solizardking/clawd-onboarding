---
name: register-agent
description: >-
  use this when attaching a Metaplex Agent Identity to an existing MPL Core
  asset with registerIdentityV1
---
# Register a Metaplex agent on an existing Core asset

Bind an identity record to an MPL Core asset you already own (`registerIdentityV1`). Creates a discoverable PDA and attaches AgentIdentity lifecycle hooks (Transfer, Update, Execute). Docs: https://www.metaplex.com/docs/agents/register-agent

If they do **not** have a Core asset yet, use [mint-agent](sand-workflow:mint-agent) instead (creates asset + identity in one tx).

SDK: `@metaplex-foundation/mpl-agent-registry` v0.2.0+. Umi + `mplAgentIdentity()`. Never load secret keys here. Build, show, operator signs (OWS).

## Ask first

- Core asset pubkey
- Collection pubkey (optional, recommended)
- `agentRegistrationUri` — permanently hosted JSON (Arweave). ERC-8004 shape.
- Network / RPC
- Payer pubkey (defaults to owner)

Registration is **one-time per asset**. Calling again fails.

## Registration JSON

```
{
  "type": "https://eips.ethereum.org/EIPS/eip-8004#registration-v1",
  "name": "<name>",
  "description": "<what it does>",
  "image": "<https avatar>",
  "services": [
    { "name": "MCP", "endpoint": "https://…/mcp", "version": "2025-06-18" },
    { "name": "A2A", "endpoint": "https://…/agent-card.json", "version": "0.3.0" }
  ],
  "active": true,
  "registrations": [{ "agentId": "<MINT_OR_ASSET>", "agentRegistry": "solana:101:metaplex" }],
  "supportedTrust": ["reputation", "crypto-economic"]
}
```

`image` is required on this document. `agentRegistry` constant is `solana:101:metaplex`.

## Build

```
registerIdentityV1(umi, {
  asset,
  collection, // optional
  agentRegistrationUri,
})
```

Return instructions / unsigned tx. Do not `sendAndConfirm` for them.

## Verify

`fetchAsset` → `agentIdentities[0].uri` and lifecycle checks. Or `safeFetchAgentIdentityV1` on `findAgentIdentityV1Pda`. Related: [metaplex-agent-data](sand-workflow:metaplex-agent-data).
