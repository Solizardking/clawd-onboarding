---
name: pump-fun-creator-fees
description: >-
  use this when collecting pump.fun creator fees, setting fee shares, or
  distributing locked reward splits
---
# Pump.fun creator fees and fee sharing

Two different jobs, mutually exclusive after migration: (1) collect creator fees to the creator, and (2) configure or distribute a fee-share split. Trading instructions are unrelated and do not need an upgrade for the one-time lock.

SDK: `@pump-fun/pump-sdk@1.36.0` (`PumpSdk`, `OnlinePumpSdk`, `isSharingConfigEditable`, `isCreatorUsingSharingConfig`, `Platform`, singleton `PUMP_SDK`)
Docs: https://github.com/pump-fun/pump-public-docs (`docs/instructions/COLLECT_CREATOR_FEE.md`, `CREATOR_FEE_SHARING.md`, `idl/pump_fees.json`)

Pump Fees program: `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ`
Sharing config PDA: `["sharing-config", mint]`
Social fee PDA: `["social-fee-pda", …]` per `(userId, platform)`; `user_id` max 20 chars
Pump creator vault seed uses a **hyphen** (`creator-vault`); AMM creator vault uses an **underscore** (`creator_vault`)

## A. No sharing_config — collect (single creator)

Two independent vaults:

1. Pump curve: `collect_creator_fee_v2` → creator wallet (SOL) or creator ATA (non-SOL)
2. PumpSwap (graduated): `collect_coin_creator_fee`

SDK: `getCreatorVaultBalanceBothPrograms(creator)` then `collectCoinCreatorFeeInstructions(creator)`.

V2 collect is permissionless. After `sharing_config` exists, **both collect ixs fail** (`CreatorMigratedToSharingConfig` / `UnableToDistributeCreatorVaultMigratedToSharingConfig`). Switch to distribute.

When Cheshire is connected, `post_api_pump_creator_fees_prepare` is an allowed builder. Same rule: prepare, show, operator signs.

## B. Has sharing_config — distribute (multi-recipient)

Lifecycle:

1. `create_fee_sharing_config` — creator (or admin_set_creator_authority) signs. Migrates `bonding_curve.creator` (and `pool.coin_creator` if graduated) to the sharing_config PDA. Initial shares: `[(creator, 10000)]`. Pass `pool` if graduated, omit/`null` if not. Calling twice is a no-op. **This is not the lock.**
2. **One-time lock:** first of `updateFeeShares` / `updateFeeSharesV2` **or** `updateSharingConfigWithSocialRecipients`. Sets final `{address, share_bps}[]`, sweeps pending fees to *current* shareholders, sets `admin_revoked = true`. Signer is `sharing_config.admin` (the original creator at create-config time).
3. Ongoing (permissionless): graduated coins need `transferCreatorFeesToPump` then `distributeCreatorFees`; ungraduated coins only `distributeCreatorFees`. Prefer `OnlinePumpSdk.buildDistributeCreatorFeesInstructions` which already branches.

Shareholder rules: 1–10 entries, no dupes, every `share_bps > 0`, **sum == 10000**. Remaining accounts must match shareholder order. Non-WSOL: pass ATAs; `initialize_ata=true` creates missing ones (payer pays rent). Executable accounts cannot receive lamports. Compute ~400k CU for distribute.

## One-time lock checklist

- Call `isSharingConfigEditable` first. Pre-policy configs are already locked.
- `createFeeSharingConfig` / `createSharingConfigWithSocialRecipients` only **creates** the config (default 100% creator). That is not the lock.
- The lock is the **first** `updateFeeShares` / `updateFeeSharesV2` or `updateSharingConfigWithSocialRecipients`. Pick one path.
- Double-check recipients and `shareBps` (sum 10000) before submit. No second update.
- `RevokeFeeSharingAuthority` / `TransferFeeSharingAuthority` are deprecated empty ixs. Do not call.
- After lock: `SharingConfigAdminRevoked` / `FeeSharesAlreadyUpdated`.
- Creating the config twice is OK (no-op). Updating shares twice is not.

## GitHub recipients (fees can be permanently lost)

Social fee PDA must exist before the GitHub user is a shareholder. Init is once per `(userId, platform)` and reusable across coins.

```
PUMP_SDK.createSharingConfigWithSocialRecipients({ creator, mint, pool /* or null */, newShareholders })
PUMP_SDK.updateSharingConfigWithSocialRecipients({ authority, mint, currentShareholders, newShareholders })
// or PUMP_SDK.createSocialFeePda
```

Shareholders may mix `{ address, shareBps }` and `{ userId, platform: Platform.GitHub, shareBps }`.

Hard rules:

1. Only `Platform.GitHub`. Other platforms → ban / lost fees.
2. GitHub **users** only, not organizations. Orgs cannot log in to claim.
3. Claim only via Pump.fun web or mobile. On-chain `claim_social_fee_pda` requires Pump’s `social_claim_authority` — agents cannot claim for the GitHub user. Point them at Pump.fun.
4. Init the PDA before locking shares.
5. Need the GitHub **numeric user id**, not an org, not a handle treated as an org. Confirm they can log into Pump.fun.

## Distribute after sharing is on

```
if (!isCreatorUsingSharingConfig({ mint, creator })) {
  // still on the simple creator vault; collect, do not distribute
}
isSharingConfigEditable(...) // before any share update
const r = await onlineSdk.getMinimumDistributableFee(mint)
// r.minimumRequired, r.distributableFees, r.canDistribute, r.isGraduated
if (r.canDistribute) {
  const { instructions, isGraduated } = await onlineSdk.buildDistributeCreatorFeesInstructions(mint)
}
```

After share setup: `bonding_curve.creator == sharing_config`, and if graduated `pool.coin_creator == sharing_config`. Canonical pool: `pool.creator` (not `coin_creator`) equals `pumpPoolAuthorityPda(baseMint)`.

## Safety

- Collect vs distribute: pick one path from `isCreatorUsingSharingConfig`. Never both.
- Setting shares is irreversible. Confirm recipients and bps twice, then submit.
- Do not send fee txs without an explicit operator yes.
- Common fails: collect after sharing_config; distribute without the gate; updating shares twice; GitHub orgs; claiming social vaults on-chain; omitting `pool` on graduated share-create or passing pool on ungraduated; mixing AMM vs Pump creator-vault seeds.
