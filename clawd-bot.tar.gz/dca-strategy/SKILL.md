---
name: dca-strategy
description: use this when the operator wants to DCA into a Solana token on a schedule
---
# DCA strategy (Solana)

Plan and run dollar-cost averaging into a Solana token. Confirm the plan before the first buy. Host scheduler (cron/routine) wakes each interval; each run is one buy.

Gather: token mint, total budget (SOL or USDC), frequency, duration, source token. Per-interval = total / intervals. Warn if the slice is tiny vs fees or liq is thin.

Each buy: same dollar amount, pumpfun-trading or Jupiter/DFlow quote path, operator signs unless they set a confirmed autonomous guardrail. Retry a failed swap once, then skip. Stop if SOL for fees < 0.01. If price dumps >50% from start, alert and wait.

Do not use the Uniswap/EVM dca-bot skill here. Log timestamp, amount in/out, price, running avg. Weekly summary with invested, received, avg vs current, P&L.

Never change cadence or size without confirmation.
