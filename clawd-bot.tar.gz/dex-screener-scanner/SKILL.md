---
name: dex-screener-scanner
description: >-
  use this when scanning DexScreener Solana listings (new, trending, gainers) or
  screening tokens by volume, liquidity, age, and holders
---
# DexScreener Solana scanner

Scan and screen Solana tokens on DexScreener. Prefer the public HTTP API when it has the data. If you need the live board (tabs, layout, pair page), use this agent's browser — not Playwright, Puppeteer, or CDP from the shell.

Triggers: scan dexscreener, find new/trending tokens, screen Solana tokens.

## Preferred: HTTP

`https://api.dexscreener.com` is unauthenticated. Use it for pair search, token pairs, and boosts. Parse JSON. Do not invent numbers if a field is missing.

If the operator wants the **board** (New / Trending / Gainers / Recently Copied), open `https://dexscreener.com/solana` in the browser.

## Browser board

DexScreener is a heavy React SPA. Wait 3–8s for rows. Selectors shift; inspect the DOM first. Prefer stable attributes (`[data-group="token-row"]`, `table tbody tr`) over class names. Wait up to 15s for the first row. Retry once on timeout.

Extract per row when present: rank, name/symbol, price, 5m/1h/6h/24h change, volume, liquidity, market cap, age, txns (buys/sells), holders, FDV/liq. Cell order changes — do not hardcode indices after a layout shift.

Tabs (wait 2–3s after each): Trending first, then New, Gainers, Recently Copied. Scroll 2–3 times (~25 tokens per batch, ~75–100 per tab). Dedup by contract address. Random 1–3s delays. Do not hammer. If Cloudflare blocks, stop and say so — do not rotate user-agents as a bypass.

For tokens that pass screening, open the pair page (`/solana/…`) for holder distribution, socials, mint, creator, and on-page rug/scam warnings. Then run [rug-check](sand-workflow:rug-check) on the mint. Never auto-buy.

## Default screens

Min liquidity $10k, min 24h volume $50k, max age 48h, min holders 50, min txns 100, FDV/liq under 50x. Loosen only if they ask. If nothing passes, say so.

Score (desc): volume and liquidity (capped), bonus if age under 1h, 5m change over 10%, holders over 200; penalty if FDV/liq over 100. Output:

```
## DexScreener Scan Results
### Top picks (passed screening)
1. **$TICKER** — score
   Price / vol / liq / age / holders
   Rationale
   CA: `mint`
### Tokens scanned
tabs, unique count, passed count
```

This is **not** a buy rec. Pair with [alpha-scanner](sand-workflow:alpha-scanner) and [risk-manager](sand-workflow:risk-manager). GeckoTerminal liquidity is [dex-pools](sand-workflow:dex-pools).
