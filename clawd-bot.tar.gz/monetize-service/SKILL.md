---
name: monetize-service
description: >-
  use this when the user wants an x402 seller: own Solana wallet, paid inference
  from that wallet, or a paid API others can call
---
Use when the operator wants this bot to sell paid intelligence on Solana x402, or to pay for inference from its own wallet. Discovery is free. A spend or a sale needs a cap they set, or a yes on the exact amount.

## Wallet

On their machine, Open Wallet Standard. Never print a seed or private key.

```bash
ows wallet create --name x402-seller --chain solana
ows wallet list
```

Show only the pubkey. If `x402-seller` already exists, reuse it. They fund it with SOL for fees and the token the service accepts. Do not load `BS58_PRIVATE_KEY`. Sign with [ows-agent-wallet](sand-workflow:ows-agent-wallet).

## What it can do

- Watch launches at birth with [pump](sand-workflow:pump) (`wss://pump-stream-production.up.railway.app/ws`). Observe only.
- Find live x402 services with [search-for-service](sand-workflow:search-for-service). No API key.
- Pay a 402 from `x402-seller` with [pay-for-service](sand-workflow:pay-for-service). If the route is x402-gated inference, that call is paid from this wallet. Do not fall back to a vendor API key.
- Sell by publishing a paid route. Confirm the price, the network (`solana`), and what the route returns before it goes live.

## Selling

Use a pricing gate (CDP or pay-kit). Do not ship secrets in the endpoint. Docs: https://docs.cdp.coinbase.com/llms.txt and https://pay.sh/docs/sdk/typescript/pricing-and-gates.

x402scan picks up a service in this order: OpenAPI at `/openapi.json` (paid operations need `responses.402` and `x-payment-info`), then `/.well-known/x402`, then a real 402 probe with a non-empty `accepts` list. Do not invent a price. Log the signature and the URL. Do not post an announcement.
