---
name: clawd
description: >-
  use this when the user runs /clawd to create an OWS Solana wallet (secret
  local only), connect to clawd-ws.fly.dev, and rank tokens to buy
---
# /clawd — mode setup: OWS wallet + clawd-ws picks

Use when the operator runs `/clawd`, `/clawd setup`, `/clawd mode`, or wants this bot to (1) generate its own Solana wallet with Open Wallet Standard, (2) hand them the secret **only on their machine**, and (3) use `https://clawd-ws.fly.dev/` to shortlist tokens to buy.

Paper first. Observe-only ranking until they confirm a buy size. Never paste mnemonics, private keys, or seed phrases into chat, logs, templates, or memory. Never load `BS58_PRIVATE_KEY` into this agent. Sign with OWS on their device.

Related: [goal](sand-workflow:goal), [ows-agent-wallet](sand-workflow:ows-agent-wallet), [wallet](sand-workflow:wallet), [buy](sand-workflow:buy), [auto](sand-workflow:auto), [solgpt-pump-stream](sand-workflow:solgpt-pump-stream), [rug-check](sand-workflow:rug-check), [risk-manager](sand-workflow:risk-manager).

## 1. Wallet (Open Wallet Standard)

On **their** Mac only (`~/.ows`, CLI `~/.ows/bin/ows` or `ows` on PATH):

```bash
ows wallet create --name clawd-mode
ows wallet list   # show Solana pubkey only
```

Local secret backup (`ows wallet export` needs an interactive TTY — it refuses pipes). Tell them to run **in Terminal.app** themselves:

```bash
mkdir -p ~/.ows/backups
ows wallet export --wallet clawd-mode | tee ~/.ows/backups/clawd-mode-secret.txt
chmod 600 ~/.ows/backups/clawd-mode-secret.txt
```

- Default wallet name: `clawd-mode`. If it already exists, reuse it unless they ask for a fresh `clawd-mode-<date>`.
- Tell them the **pubkey** and that the secret is only in the OWS vault + the backup file they create. Never capture export stdout in tools. Never read the backup into the agent. Never put secrets in chat.
- Do not pass `--show-mnemonic` on create when tool stdout is captured.
- Ask them to fund the pubkey with SOL before live buys. Do not reuse `agent-treasury` or `pump-agent` for `/clawd` mode.

## 2. Connect clawd-ws

Same relay as `/goal`:

- Origin: `https://clawd-ws.fly.dev/`
- WS: `wss://clawd-ws.fly.dev/ws`
- Health: `GET https://clawd-ws.fly.dev/health` (never print `rpcHttp` / `rpcWs` / API keys)

## 3. Rank tokens (observe)

Listen ~60s on the WS (dedup `mint||signature`). Score and show top 5–8:

| Signal | Prefer |
|--------|--------|
| `isV2` | true |
| `hasGithub` / `githubUrls` | present |
| socials | at least one of website/twitter/telegram |
| `marketCapSol` | roughly 20–80 SOL (skip dust unless they want snipes) |
| enrichment | holders / marketCapUsd when present |

Hard filters before buy shortlist: rug-check + risk-manager (baseline −8% stop, +20% TP, ≤10% of wallet, ≤2% slippage). Optional `POST https://clawd-ws.fly.dev/api/analyze/{mint}` only if asked.

Do **not** auto-buy. Present mint, symbol, score reasons, Solscan.

## 4. Buy (after they pick)

1. Confirm mint + SOL size + paper vs live.
2. Paper: journal only.
3. Live: curve → Pump `buy_v2`; graduated → Jupiter `/order`+`/execute`. Sign with OWS on `clawd-mode`.
4. Log signature + Solscan only.

## 5. Status

`/clawd status` — pubkey (no secrets), health, last shortlist.
`/clawd listen` — listen + re-rank.
`/clawd stop` — beach any `/clawd` buy routine.

Pack this skill with `/goal` + `hello-tape` in the public template. Keys stay on the installer's device.
