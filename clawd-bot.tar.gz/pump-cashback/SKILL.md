---
name: pump-cashback
description: >-
  use this when enabling, claiming, or explaining pump.fun cashback or volume
  incentives (claim_cashback_v2, two UVAs)
---
# Pump.fun cashback and volume

Two different rewards. Cashback is creator-fee rebate into a UserVolumeAccumulator. Token incentives are a separate mint from `GlobalVolumeAccumulator`. Docs: https://github.com/pump-fun/pump-public-docs (`docs/PUMP_CASHBACK_README.md`, `docs/instructions/CLAIM_CASHBACK.md`)

There are **two** UVAs per wallet, same seeds `["user_volume_accumulator", user]`, different programs (Pump vs Pump AMM).

## Creating a cashback coin

Set cashback true / `is_cashback_enabled` `[true]` on `create_v2`. Global `is_cashback_enabled` must be on (`CashbackNotEnabled` otherwise). On v2 trades cashback is automatic because UVA is a required account. Do not silently set cashback true.

Cashback **coins** (`is_cashback_coin`): creator fees go to traders, not a creator vault. Do not collect a creator vault.

## Read unclaimed

- Bonding curve (Pump): UVA lamports minus rent. Also `stable_cashback_earned - total_stable_cashback_claimed` for USDC-paired cashback in the UVA quote ATA.
- AMM: token balance of the AMM-UVA WSOL ATA.

## Claim

Prefer **`claim_cashback_v2`** for everything. Permissionless: recipient `user` does **not** sign.

- SOL: `quoteMint = NATIVE_MINT` (`So11111111111111111111111111111111111111112`) + legacy SPL token program. Drains lamports above rent to `user`.
- Non-SOL: pass that quote mint + its token program (ATA transfer).
- `claim_cashback` (no v2) is SOL-only and will not drain USDC cashback.
- AMM `claim_cashback` needs the user WSOL ATA created idempotently first.

fun-block `POST /agents/collect-fees` can claim user cashback on cashback coins.

## Incentives (not cashback)

`claim_token_incentives` pays a separate incentive mint. `sync_user_volume_accumulator` first if the user is behind the global accumulator. If they ask to claim rewards and both exist, cashback first, then incentives, and say they are different.

## Close

`close_user_volume_accumulator` recovers 0.0018444 SOL rent. **User must sign.** Refuse to close if unclaimed cashback or incentives remain.

Admin `toggle_cashback_enabled` is protocol-global. Do not call it.
