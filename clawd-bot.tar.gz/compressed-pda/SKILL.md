---
name: compressed-pda
description: >-
  use this for Light Protocol compressed accounts/PDAs (create, update, close,
  burn)
---
# Compressed PDAs (Light)

~160x cheaper, no rent-exemption for per-user state. Create, update, close, burn, reinitialize compressed accounts. Use for DePIN registrations or custom compressed state. Pair with [zk](sand-workflow:zk) for attestations.
