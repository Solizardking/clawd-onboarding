---
name: mint-agent
description: >-
  use this when minting a new Metaplex onchain AI agent (MPL Core + Agent
  Identity PDA) via mintAgent / mintAndSubmitAgent
---
# Mint a Metaplex agent

Register a new onchain AI agent in one flow: hosted metadata + unsigned Solana tx that creates an MPL Core asset and an Agent Identity PDA together. Docs: https://www.metaplex.com/docs/agents/mint-agent

SDK: `@metaplex-foundation/mpl-agent-registry` **v0.2.0+**, plus `@metaplex-foundation/umi` and `@metaplex-foundation/umi-bundle-defaults`. API: `POST https://api.metaplex.com/v1/agents/mint` (no API key). Default base URL `https://api.metaplex.com`.

Prefer **`mintAgent`** (unsigned tx) then sign with [ows-agent-wallet](sand-workflow:ows-agent-wallet). Do **not** use `mintAndSubmitAgent` with `createKeypairFromSecretKey` in this bot. Never load, log, or paste secret keys. Operator confirms before submit.

If they already own a Core asset, use [register-agent](sand-workflow:register-agent) (`registerIdentityV1`) instead.

## Ask first

- Network: `solana-mainnet` (default) or `solana-devnet` (also eclipse/sonic/fogo — RPC must match)
- Agent name + description
- Public `uri` for Core NFT metadata JSON (Arweave/Irys/https). Must be reachable.
- `agentMetadata` (off-chain, stored by Metaplex API): `type: "agent"`, name, description, optional `services[]` (`name` + `endpoint`, e.g. trading / MCP / A2A), `registrations[]`, `supportedTrust[]` (`tee`, `reputation`, `crypto-economic`)
- Wallet pubkey that pays and becomes owner (OWS `pump-agent` or whichever they name)

`uri` (onchain Core metadata) and `agentMetadata` (API index) are different. Both are set at mint. `mintAndSubmitAgent` / `mintAgent` creates a **new** Core asset every call — no dedup.

## Build

```
npm install @metaplex-foundation/mpl-agent-registry @metaplex-foundation/umi @metaplex-foundation/umi-bundle-defaults
```

Umi: `createUmi(rpc).use(mplAgentIdentity())`. Do not attach `keypairIdentity` from raw secret bytes.

Call `mintAgent(umi, { baseUrl? }, { wallet, name, uri, agentMetadata, network? })`. Returns unsigned tx + precomputed `assetAddress`. Show those. Operator signs (`signAndSendAgentTransaction` only if they already have a local signer they control, else OWS `ows sign tx`). Optional custom `txSender` for Jito / priority fees.

Devnet: RPC `https://api.devnet.solana.com` and `network: 'solana-devnet'`. Cost: normal tx fee + rent for Core asset + identity PDA. No extra Metaplex mint fee.

## Verify

`fetchAsset` then `assetData.agentIdentities?.[0]`. Need `uri` plus Transfer/Update/Execute lifecycle checks (`Listen`). Empty `agentIdentities` means it did not register — check the signature before retrying. Blockhash expired: call `mintAgent` again for a fresh tx.

Errors: `isAgentValidationError` (field), `isAgentApiNetworkError`, `isAgentApiError` (status + body).

Related: [register-agent](sand-workflow:register-agent), [metaplex-agent-data](sand-workflow:metaplex-agent-data), [metaplex-agent-token](sand-workflow:metaplex-agent-token), [run-agent](sand-workflow:run-agent).
