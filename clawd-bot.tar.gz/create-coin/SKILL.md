---
name: create-coin
description: >-
  use this when creating a pump.fun coin with an initial buy via
  fun-block.pump.fun or @pump-fun/pump-sdk
---
# Create a pump.fun coin

Prefer the official agent API. Scripts are a fallback only when the operator explicitly asks. Builders return a partial-signed VersionedTransaction. Never sign or send for the user. Never log private keys.

API origin: `https://fun-block.pump.fun`
SDK: `@pump-fun/pump-sdk@1.36.0` (not community forks). Tokenized agents: `@pump-fun/agent-payments-sdk@3.0.3` (bonding-curve SDK still pins 1.0.7; do not mix majors casually).
Docs: https://github.com/pump-fun/pump-public-docs (`docs/instructions/COIN_CREATION.md`)
Pump program: `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`

## Ask before any code or tx

- RPC URL (public `api.mainnet-beta.solana.com` often cannot send)
- Signer wallet pubkey (fee payer / user)
- Framework
- Name ≤ 32, symbol ≤ 13, uri ≤ 200
- Initial buy in lamports (9 decimals). Tokenized agents need initial buy > 0
- Cashback? default off (`is_cashback_enabled` is Anchor OptionBool: TS `[true]` / `[false]`, not a plain bool)
- Mayhem mode? default off. Mayhem plus a non-SOL quote is rejected (`MayhemModeQuoteMintNotAllowed`)
- Quote mint? default SOL. Non-SOL must be in `Global.whitelisted_quote_mints` (USDC example `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`)
- Tokenized agent? default off. If yes, buyback bps (default 5000)
- Front-runner protection? If yes, Jito tip; send **only** to Jito

## Preferred API — `POST https://fun-block.pump.fun/agents/create-coin`

Always `"encoding": "base64"`. Required: `user`, `name`, `symbol`, `uri`, `solLamports`. Optional: `mayhemMode`, `cashback`, `tokenizedAgent`, `buybackBps`, `frontRunningProtection`, `tipAmount`, `feePayer`, `creator`. Server generates the mint keypair and partial-signs.

## create_v2 (Token-2022)

New coins use Token-2022 (`TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb`), decimals 6, metadata pointer = mint, no Metaplex account. Mint must be a **Keypair signer**, not `PublicKey.unique()`. Creator does **not** sign. Token-2022 program is hardcoded.

Mayhem accounts (program `MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e`, global-params, sol-vault, mayhem-state, mayhem-token-vault) are **always** in the list, even when mayhem is false.

Non-SOL quote remaining accounts: all three or none, this order: (1) `quote_mint` (2) `associated_quote_bonding_curve` (3) `quote_token_program` which **must** be legacy SPL Token (`TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA`). Omitting them (or passing wSOL) sets `bonding_curve.quote_mint` to default pubkey (SOL-paired). Trading still uses native SOL. Confirm whitelist first (`UnsupportedQuoteMint`).

TS: `PUMP_SDK.createV2Instruction({ mint, name, symbol, uri, creator, user, mayhemMode, cashback, quoteMint? })`. Create+buy ~390k CU; +tokenized agent ~420k.

If `create_v2` fails with `CreateV2Disabled` / `MayhemModeDisabled` / `CashbackNotEnabled`, that is a protocol flag, not an agent bug.

## Tokenized agents

Separate program, not in the pump IDL. After create plus a non-zero initial buy, append `PumpAgentOffline.load(mint).create({ authority, mint, agentAuthority, buybackBps })` (~30k extra CU). Buy/sell account lists do not change. fun-block: `tokenizedAgent: true`, `buybackBps: 5000`.

## Send

Always `encoding: "base64"`. No Jito: `sendRawTransaction` + `confirmTransaction`. Front-runner protection: Jito block engines only. Never trust `coins-v2` `token_program`; resolve mint owner on-chain.
