---
name: imperial-skills-index
description: use this to discover the correct focused Imperial perps skill
---
Imperial pack: imperial, imperial-execution-modes, imperial-market-intel, imperial-portfolio-intel, imperial-position-management, imperial-risk-management, imperial-trade-execution, imperial-tpsl-management, imperial-margin-operations, imperial-twap-execution, imperial-grid-trading. Default Phoenix via Imperial. Flash/Jupiter/GMTrade only on request or better route. Start at [imperial](sand-workflow:imperial).
