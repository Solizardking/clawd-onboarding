---
name: vulcan-twap-execution
description: use this for TWAP on Phoenix perps via Vulcan's first-class runner
---
Prefer `vulcan strategy twap start` or MCP `vulcan_strategy_twap_start`. Report every slice, fill, dry-run action, paper fill ID, and signature. Do not fake TWAP with a chat loop.
