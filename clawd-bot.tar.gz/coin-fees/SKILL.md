---
name: coin-fees
description: >-
  use this when inspecting, collecting, or distributing pump.fun creator fees,
  or setting a one-time sharing config
---
# Coin fees on pump.fun

Inspect fee destination, collect, distribute, or lock a sharing config. Prefer `https://fun-block.pump.fun` so quote-mint branching is server-side. Never sign for the user.

SDK: `@pump-fun/pump-sdk@1.36.0`. Programs: Pump `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P`, AMM `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA`, Fees `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ`.
Docs: https://github.com/pump-fun/pump-public-docs (`COLLECT_CREATOR_FEE.md`, `CREATOR_FEE_SHARING.md`)

Always `"encoding": "base64"` on fun-block. `POST /agents/collect-fees` auto-detects sharing vs collect. `POST /agents/sharing-config` auto-detects create vs update. Shareholders `bps` sum **exactly 10000**, max 10, no dupes, each bps > 0.

## Destination tree

1. Fetch curve + pool (graduated?)
2. `is_cashback_coin` → traders via UVA. No creator vault. collect-fees claims the user's cashback.
3. Else `isCreatorUsingSharingConfig` → distribute, do not collect. `bonding_curve.creator` (and graduated `pool.coin_creator`) **is** the sharing_config PDA (owned by the fees program).
4. Else collect to creator vault.

## Collect vs distribute (v2)

No sharing_config: `collect_creator_fee_v2` (curve; SOL lamports or quote ATA) and, if graduated, `collect_coin_creator_fee` (AMM). Both permissionless. Call **both** to fully sweep a graduated coin. These fail once migrated to sharing_config (`CreatorMigratedToSharingConfig`).

Sharing_config present: collect ixs FAIL. Graduated: `transfer_creator_fees_to_pump_v2` then `distribute_creator_fees_v2` with `initialize_ata`. Ungraduated: distribute only. Check `get_minimum_distributable_fee` / `OnlinePumpSdk.getMinimumDistributableFee(mint)` (`canDistribute`) first. ConfigStatus must be Active.

SOL path: lamport transfer, leave vault rent-exempt; ATAs unused. Non-SOL: token transfer vault ATA to dest ATA. Remaining accounts must match `shareholders` order: SOL = `[s1..sN]`; non-SOL = `[s1..sN, ata1..ataN]`. `initialize_ata=true` creates missing ATAs (payer pays rent). Executable accounts cannot receive lamports.

Prefer SDK `buildDistributeCreatorFeesInstructions` / `collectCoinCreatorFeeInstructions`. ~200k CU collect; ~400k distribute.

## One-time lock

`createFeeSharingConfig` is **not** the lock (initial shares `[(creator, 10000)]`, calling twice is a no-op). The lock is the **first** of `updateFeeShares` / `updateFeeSharesV2` / `updateSharingConfigWithSocialRecipients`. Sweeps pending fees first. `isSharingConfigEditable` before any update. Pre-policy configs are already locked. `RevokeFeeSharingAuthority` / `TransferFeeSharingAuthority` are empty stubs. Confirm recipients twice.

GitHub social: `Platform.GitHub` only, users not orgs, init social fee PDA first (`createSocialFeePda`, once per `(userId, platform)`). Claim only in Pump.fun apps (`claim_social_fee_pda_v2` is still app-gated). Do not build an external social-claim flow.

PDAs: Pump creator vault seed hyphen `creator-vault`; AMM underscore `creator_vault`; sharing-config on Fees program.
