---
name: vulcan-lot-size-calculator
description: use this whenever a Vulcan command needs size or Phoenix base lots
---
Never guess Phoenix lot sizes. `vulcan market info <SYMBOL> -o json` before `size`. Prefer `--tokens` or `--notional-usdc` on market orders when supported.
