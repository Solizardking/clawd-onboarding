---
name: pump-program-ids
description: >-
  use this when you need pump.fun program IDs, PDAs, or the 24 fee-recipient
  addresses for v2 trades
---
# Pump.fun program IDs and fee recipients

Canonical docs: https://github.com/pump-fun/pump-public-docs (`docs/FEE_RECIPIENTS.md`). Use these IDs; do not invent.

## Programs (mainnet = devnet)

- Pump: `6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P` — Global `4wTV1YmiEkRvAtNtsSGPtUrqRYQMe5SKy2uB4Jjaxnjf` seed `["global"]`
- PumpSwap AMM: `pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA` — GlobalConfig `ADyA8hdefvWN2dbGGWFotbzWxrAvLW83WG6QCVXvJKqw` seed `["global_config"]`
- Pump Fees: `pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ` (sharing-config and fee_config live **here**)
- Mayhem: `MAyhSmzXzV1pTf7LsNkrNwkWKTo4ougAJ1PPg47MD4e` — always passed on create_v2 even if mayhem is false
- Token-2022: `TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb`
- Legacy SPL Token: `TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA` (required for quote mints)
- wSOL: `So11111111111111111111111111111111111111112`
- USDC example: `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v`

Every v2 buy/sell needs BOTH feeRecipient and buybackFeeRecipient. Randomize index within the correct group.

Non-mayhem feeRecipient (8):
`62qc2CNXwrYqQScmEdiZFFAnJR262PxWEuNQtxfafNgV`, `7VtfL8fvgNfhz17qKRMjzQEXgbdpnHHHQRh54R9jP2RJ`, `7hTckgnGnLQR6sdH7YkqFTAA7VwTfYFaZ6EhEsU3saCX`, `9rPYyANsfQZw3DnDmKE3YCQF5E8oD89UXoHn9JFEhJUz`, `AVmoTthdrX6tKt4nDjco2D775W2YK3sDhxPcMmzUAmTY`, `CebN5WGQ4jvEPvsVU4EoHEpgzq1VV7AbicfhtW4xC9iM`, `FWsW1xNtWscwNmKv6wVsU1iTzRN6wmmk3MjxRP5tT7hz`, `G5UZAVbAf46s7cKWoyKu8kYTip9DGTpbLZ2qa9Aq69dP`

Mayhem reserved feeRecipient (8):
`GesfTA3X2arioaHp8bbKdjG9vJtskViWACZoYvxp4twS`, `4budycTjhs9fD6xw62VBducVTNgMgJJ5BgtKq7mAZwn6`, `8SBKzEQU4nLSzcwF4a74F2iaUDQyTfjGndn6qUWBnrpR`, `4UQeTP1T39KZ9Sfxzo3WR5skgsaP6NZa87BAkuazLEKH`, `8sNeir4QsLsJdYpc9RZacohhK1Y5FLU3nC5LXgYB4aa6`, `Fh9HmeLNUMVCvejxCtCL2DbYaRyBFVJ5xrWkLnMH6fdk`, `463MEnMeGyJekNZFQSTUABBEbLnvMTALbT6ZmsxAbAdq`, `6AUH3WEHucYZyC61hqpqYUWVto5qA5hjHuNQ32GNnNxA`

BuybackFeeRecipient for every coin (8):
`5YxQFdt3Tr9zJLvkFccqXVUwhdTWJQc1fFg2YPbxvxeD`, `9M4giFFMxmFGXtc3feFzRai56WbBqehoSeRE5GK7gf7`, `GXPFM2caqTtQYC2cJ5yJRi9VDkpsYZXzYdwYpGnLmtDL`, `3BpXnfJaUTiwXnJNe7Ej1rcbzqTTQUvLShZaWazebsVR`, `5cjcW9wExnJJiqgLjq7DEG75Pm6JBgE1hNv4B2vHXUW6`, `EHAAiTxcdDwQ3U4bU6YcMsQGaekdzLS3B5SmYo46kJtL`, `5eHhjP8JaYkz83CWwvGU2uMUXefd3AazWGx4gpcuEEYD`, `A7hAgCzFw14fejgCp387JUJRMNyz4j89JKnhtKU8piqW`

Wrong group → `BuybackFeeRecipientNotAuthorized` or reserved-recipient errors.

Never call admin toggles (`toggle_create_v2`, `toggle_mayhem_mode`, `toggle_cashback_enabled`, `add_quote_mint`, `set_params`, `update_global_authority`, buyback vault sweep, donation PDAs). Surface `CreateV2Disabled` / `MayhemModeDisabled` / `CashbackNotEnabled` as protocol state.
