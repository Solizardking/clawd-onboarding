---
name: solana-dev
description: >-
  use this for general Solana program/client development (Anchor, Token-2022,
  simulation, CPI)
---
# Solana dev patterns

Anchor IDL, SPL + Token-2022, instruction composition, RPC batching, account decode, simulation, BN math, CPI. Prefer Helius RPC/DAS. Never load raw secret keys. For Pump-specific patterns see [pump-solana-dev](sand-workflow:pump-solana-dev). Formal proofs: [qedgen](sand-workflow:qedgen) / solana-formal-verification.
